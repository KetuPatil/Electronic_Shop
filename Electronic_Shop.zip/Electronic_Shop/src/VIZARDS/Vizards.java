package VIZARDS;

//Exception
import java.util.InputMismatchException;
//Import In-Build Scanner
import java.util.Scanner;


interface Shop
{
	public void printDetails();
}

//Super-Class
class Storage implements Shop
{     
  private long   productId;
	String productName;
	double price;
	String category;
	String colour;

	//Storage Constructor 
	public Storage(long productId, String productName, double price, String category, String colour) 
	{
		super();
		this.productId = productId;
		this.productName = productName;
		this.price = price;
		this.category = category;
		this.colour = colour;
	}
	@Override
	public void printDetails() 
	{
		
	    System.out.println("Product ID: " +getProductId());
	    System.out.println("Product Name: " +productName);
	    System.out.println("Price: " +price + " Rupees");
	    System.out.println("Category of: " +category);
	    System.out.println("Available Colour: " +colour);
	 }
	 public long getProductId()
	 {
		 return productId;
	 }
}


//class for Home Appliances
class Home extends Storage
{
	//Home Constructor;
	public Home(long productId, String productName, double price, String category, String colour) 
{
 	super(productId,productName,price,category,colour);
  //	this.id = id;
}

public void HomeDetails() 
{
  printDetails();
 // System.out.println("id: " + id );
}

}



//Class For Kitchen Appliances
class Kitchen extends Storage
{
	//Kitchen Constructor;
	public Kitchen(long productId, String productName, double price, String category, String colour) 
{
 	super(productId,productName,price,category,colour);
  //	this.id = id;
}

public void KitchenDetails() 
{
  printDetails();
 // System.out.println("id: " + id );
}

}

//Class For Laptops
class Laptops extends Storage
{
	//Laptops Constructor;
	public Laptops(long productId, String productName, double price, String category, String colour) 
{
 	super(productId,productName,price,category,colour);
  //	this.id = id;
}

public void LaptopsDetails() 
{
  printDetails();
 // System.out.println("id: " + id );
}

}

//Class For Computers
class Computers extends Storage
{
	//Computers Constructor;
	public Computers(long productId, String productName, double price, String category, String colour) 
  {
	super(productId,productName,price,category,colour);
  //this.id = id;
  }

	public void ComputersDetails() 
	{
	 printDetails();
	 // System.out.println("id: " + id );
	}

}

//Class For Televisions
class Televisions extends Storage
{
	//Televisions Constructor;
	public Televisions(long productId, String productName, double price, String category, String colour) 
{
	super(productId,productName,price,category,colour);
//this.id = id;
}

	public void TelevisionsDetails() 
	{
	 printDetails();
	 // System.out.println("id: " + id );
	}

}

//Class For Mobiles
class Mobiles extends Storage
{
	//Mobiles Constructor;
	public Mobiles(long productId, String productName, double price, String category, String colour) 
{
	super(productId,productName,price,category,colour);
//this.id = id;
}

	public void MobilesDetails() 
	{
	 printDetails();
	 // System.out.println("id: " + id );
	}

}

//Class For Audio
class Audio extends Storage
{
	//Audio Constructor;
	public Audio(long productId, String productName, double price, String category, String colour) 
{
	super(productId,productName,price,category,colour);
//this.id = id;
}

	public void AudioDetails() 
	{
	 printDetails();
	 // System.out.println("id: " + id );
	}

}

//Class For Tablets
class Tablets extends Storage
{
	//Audio Constructor;
	public Tablets(long productId, String productName, double price, String category, String colour) 
{
	super(productId,productName,price,category,colour);
//this.id = id;
}

	public void TabletsDetails() 
	{
	 printDetails();
	 // System.out.println("id: " + id );
	}

}

//Class For Wearables
class Wearables extends Storage
{
	//Wearables Constructor;
	public Wearables(long productId, String productName, double price, String category, String colour) 
{
	super(productId,productName,price,category,colour);
//this.id = id;
}

	public void WearablesDetails() 
	{
	 printDetails();
	 // System.out.println("id: " + id );
	}

}


////////////*SUB Class Of Sub Class*/////////////



//Sub Class Of Home Appliances //

class WashingMachine extends Home 
{

	public WashingMachine(long productId, String productName, double price, String category, String colour) 
	{
		super(productId,productName,price,category,colour);
	}
    
	public void WashingMachineDetails() 
	{
		
	    System.out.println("Product ID: " +getProductId());
	    System.out.println("Product Name: " +productName);
	    System.out.println("Price: " +price + " Rupees");
	    System.out.println("Category of: " +category);
	    System.out.println("Seleted Colour: " +colour);
	 }
}

class AirConditioner extends Home 
{

	public AirConditioner(long productId, String productName, double price, String category, String colour) 
	{
		super(productId,productName,price,category,colour);
	}
  
	public void AirConditionerDetails() 
	{
		
	    System.out.println("Product ID: " +getProductId());
	    System.out.println("Product Name: " +productName);
	    System.out.println("Price: " +price + " Rupees");
	    System.out.println("Category of: " +category);
	    System.out.println("Seleted Colour: " +colour);
	 }
}

class Refrigerators extends Home 
{

	public Refrigerators(long productId, String productName, double price, String category, String colour) 
	{
		super(productId,productName,price,category,colour);
	}
  
	public void RefrigeratorsDetails() 
	{
		
	    System.out.println("Product ID: " +getProductId());
	    System.out.println("Product Name: " +productName);
	    System.out.println("Price: " +price + " Rupees");
	    System.out.println("Category of: " +category);
	    System.out.println("Seleted Colour: " +colour);
	 }
}

//Sub Class Of Home Appliances //

//Sub Class Of Kitchen Appliances //

class ElectricChimneys extends Kitchen 
{

	public ElectricChimneys(long productId, String productName, double price, String category, String colour) 
	{
		super(productId,productName,price,category,colour);
	}
    
	public void ElectricChimneysDetails() 
	{
		
	    System.out.println("Product ID: " +getProductId());
	    System.out.println("Product Name: " +productName);
	    System.out.println("Price: " +price + " Rupees");
	    System.out.println("Category of: " +category);
	    System.out.println("Seleted Colour: " +colour);
	 }
}


class DishWashers extends Kitchen 
{

	public DishWashers(long productId, String productName, double price, String category, String colour) 
	{
		super(productId,productName,price,category,colour);
	}
  
	public void DishWashersDetails() 
	{
		
	    System.out.println("Product ID: " +getProductId());
	    System.out.println("Product Name: " +productName);
	    System.out.println("Price: " +price + " Rupees");
	    System.out.println("Category of: " +category);
	    System.out.println("Seleted Colour: " +colour);
	 }
}

class WaterPurifiers extends Kitchen 
{

	public WaterPurifiers(long productId, String productName, double price, String category, String colour) 
	{
		super(productId,productName,price,category,colour);
	}
  
	public void WaterPurifiersDetails() 
	{
		
	    System.out.println("Product ID: " +getProductId());
	    System.out.println("Product Name: " +productName);
	    System.out.println("Price: " +price + " Rupees");
	    System.out.println("Category of: " +category);
	    System.out.println("Seleted Colour: " +colour);
	 }
}

//Sub Class Of Kitchen Appliances //

//Sub Class Of Laptops//

class MacLaptops extends Laptops 
{

	public MacLaptops(long productId, String productName, double price, String category, String colour) 
	{
		super(productId,productName,price,category,colour);
	}
    
	public void MacLaptopsDetails() 
	{
		
	    System.out.println("Product ID: " +getProductId());
	    System.out.println("Product Name: " +productName);
	    System.out.println("Price: " +price + " Rupees");
	    System.out.println("Category of: " +category);
	    System.out.println("Seleted Colour: " +colour);
	 }
}


class DellLaptops extends Laptops 
{

	public DellLaptops(long productId, String productName, double price, String category, String colour) 
	{
		super(productId,productName,price,category,colour);
	}
  
	public void DellLaptopsDetails() 
	{
		
	    System.out.println("Product ID: " +getProductId());
	    System.out.println("Product Name: " +productName);
	    System.out.println("Price: " +price + " Rupees");
	    System.out.println("Category of: " +category);
	    System.out.println("Seleted Colour: " +colour);
	 }
}

class AsusLaptops extends Laptops 
{

	public AsusLaptops(long productId, String productName, double price, String category, String colour) 
	{
		super(productId,productName,price,category,colour);
	}
  
	public void AsusLaptopsDetails() 
	{
		
	    System.out.println("Product ID: " +getProductId());
	    System.out.println("Product Name: " +productName);
	    System.out.println("Price: " +price + " Rupees");
	    System.out.println("Category of: " +category);
	    System.out.println("Seleted Colour: " +colour);
	 }
}


//Sub Class Of Laptops //


//Driver Class 
public class Vizards
{
  String Username;
  String Address;
  long Number;

	static
	{
		System.out.println(" ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("| WELCOME TO VIZARDS ELECTRONIC |");
		System.out.println(" ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println(" ");
	} 
	
	Vizards()
	{
		login();
		
	}
	public void login()
	{
		System.out.println("Enter Your Details");
		Scanner login = new Scanner(System.in);
		System.out.println("==================");
		System.out.print("Enter Your Name :");
		String Username =login.nextLine();
		System.out.print("Enter Your Address :");
		String Address =login.nextLine();
		try
		{
	    System.out.print("Enter Your Mobile No :");
	    long Number =login.nextLong();
	    this.Number=Number;
	    System.out.println(" ");
	    
		System.out.println("Details Registration Successfully");
		System.out.println(" ");
		}
		catch(InputMismatchException Mob)
		{ 
			System.out.println(" ");
			System.out.println("Invalid Number Plz Try Again ....(E.g - 12345)");
			System.out.println(" ");
			login();
		}
		
		this.Username=Username;
		this.Address=Address;
		
		
	}
	
	
 public void logout()
 {
	   System.out.println("");
 }
	public void Delivery()
	{     System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢");
		  System.out.println("◢◤"+"Your Product Will Be Delivery To Your Given Address :"+Address);
		  System.out.println("◢◤"+"Buyer Name :"+Username);
		  System.out.println("◢◤"+"Buyer Contact Number :"+Number);
		  System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢");
		  System.out.println("");
		  System.out.println("........ Thank You For Purchasing From Vizards Electronic ........ <3000 ");
		  
	}

public static void main(String[] args) 
	{
	    Vizards vz=new Vizards();
     //Scanner sc = new Scanner(System.in) ~ Take Input From User;
	 	Scanner sc = new Scanner(System.in);
	 	System.out.println("VIZARDS ELECTRONIC CATEGORYS");
	 	System.out.println("-----------------------------");
	 	System.out.println(" ");
		System.out.println("Enter 1 for Home Appliances:");
		System.out.println("Enter 2 for Kitchen Appliances:");
		System.out.println("Enter 3 for Laptops:");
		/*
		System.out.println("Enter 4 for Computers:");
		System.out.println("Enter 5 for Televisions:");
		System.out.println("Enter 6 for Mobiles:");
		System.out.println("Enter 7 for Audio:");
		System.out.println("Enter 8 for Tablets:");
		System.out.println("Enter 9 for Wearables:");*/
		System.out.println("-----------------------------");
		System.out.print("Enter Your Desired Category Sir/Ma'am: ");
		int Vcategory= sc.nextInt();
		switch(Vcategory)
	 {
		//------------------------------------Home Appliances Start Switch------------------------------------//
		case 1:
		System.out.println("Your Selected Category: Home Appliances");
		System.out.println(" ");
		System.out.println("Home Appliances Category Sections :");
		System.out.println("========================");
		System.out.println("1.Washing Machine");
		System.out.println(" ");
		System.out.println("2.Air Conditioner");
		System.out.println(" ");
		System.out.println("3.Refrigerators");
		System.out.println("========================");
		System.out.println(" ");
		System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
		System.out.print("Select the Appliances :");
		int HomeAppliances = sc.nextInt();
		     switch (HomeAppliances) 
		     {
		
		            case 1://Washing Machine Start
		            System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
		            System.out.println(" ");
		            System.out.println("Washing Machine Section :");
		            System.out.println("========================");
			        System.out.println("1.Voltas Beko 7C Semi Automatic");
			        System.out.println(" ");
			        System.out.println("2.Midea 6T Fully Automatic");
			        System.out.println(" ");
			        System.out.println("3.Whirlpool 9R Automatic With Dryer");
			        System.out.println("========================");
			        System.out.println(" ");
			        System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
			        System.out.print("Select Your Washing Machine :");
			        int WashingMachine = sc.nextInt();
			        System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
			        switch (WashingMachine) 
			        {
			        			case 1://Voltas Beko 7 Start
			        			System.out.println(" ");
			        			System.out.println("⊱---------------------⊰");
			        			//long productId, String productName, double price, String category, String colour
			        			//Upcasting 
			        			Home m1 = new WashingMachine(78952,"Voltas Beko 7",9600,"Washing Machine","Grey & Yellow");
			        			m1.HomeDetails();
			        			System.out.println("⊱---------------------⊰");
			        			System.out.println(" ");
			        			System.out.println("Choose Your Colour");
			        			System.out.println("===================");
			        			System.out.println("1.Grey");
			        			System.out.println("2.Yellow");
			        			System.out.println("===================");
			        			System.out.println(" ");
			        			System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
			        			System.out.print("Which Colour Your Prefer :");
			        			            //Switch For Colour Choosing 
			        						int WasColour =sc.nextInt();
			        						System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
			        						switch(WasColour)
			        						{
			        						case 1:
			        								System.out.println(" ");
			        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
			        								WashingMachine m2 = new WashingMachine(78952,"Voltas Beko 7",9600,"Washing Machine","Grey");
			        								m2.WashingMachineDetails();
			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
			        								System.out.println(" ");
			        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
			        								System.out.println("============================");
			        								System.out.println("1.Purchase");
			        								System.out.println(" ");
			        								System.out.println("2.Exit");
			        								System.out.println("============================");
			        								System.out.print("Select Your Option :");
			        								          int purchase =sc.nextInt();
			        								          switch(purchase)
			        								          {
			        								          case 1:
			        								        	  System.out.println(" ");
			        								        	  vz.Delivery();
			        								          break;
			        								        	  
			        								          case 2:
			        								           System.out.println(" ");
			        								           System.out.println("Thank You For Visiting");
			        								           System.out.println("Plz Login Again If U Want To Purchase Something");
			        								           System.out.println(" ");
			        								           vz.login();
			        								          break;
			        								          
			        								          default:
	      		        								          System.out.println(" ");
	      		        								          System.out.println("Invalid Macha Try Again");
			        								          
			        								          }
			        		                break;//Product Colour 1
			        						case 2:
		        								System.out.println(" ");
		        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
		        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
		        								WashingMachine m3 = new WashingMachine(78952,"Voltas Beko 7",9600,"Washing Machine","Yellow");
		        								m3.WashingMachineDetails();
		        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
		        								System.out.println(" ");
		        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
		        								System.out.println("============================");
		        								System.out.println("1.Purchase");
		        								System.out.println(" ");
		        								System.out.println("2.Exit");
		        								System.out.println("============================");
		        								System.out.print("Select Your Option :");
		        								          int purchase2 =sc.nextInt();
		        								          switch(purchase2)
		        								          {
		        								          case 1:
		        								        	  System.out.println(" ");
		        								        	  vz.Delivery();
		        								          break;
		        								        	  
		        								          case 2:
		        								           System.out.println(" ");
		        								           System.out.println("Thank You For Visiting");
		        								           System.out.println("Plz Login Again If U Want To Purchase Something");
		        								           System.out.println(" ");
		        								           vz.login();
		        								          break;
		        								          
		        								          default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Macha Try Again");
			        					     
		        								          }			        								          
			        						      break;//Product Colour 2
			        						      
			        						default:
      								          System.out.println(" ");
      								          System.out.println("Invalid Colour Macha Try Again");
			        						      
			        					   	}//Colour Close
			        						
			        			
			        			break;//Voltas Beko 7 End
			        			
			        			case 2://Midea 6T Fully Automatic Start
			        				System.out.println(" ");
			        				System.out.println("⊱---------------------⊰");
			        				//long productId, String productName, double price, String category, String colour
			        				//Upcasting 
			        				Home m4 = new WashingMachine(789522,"Midea 6T Fully Automatic",10600,"Washing Machine","Red Or Violet");
			        				m4.HomeDetails();
			        				System.out.println("⊱---------------------⊰");
			        				System.out.println(" ");
			        				System.out.println("Choose Your Colour");
			        				System.out.println("===================");
			        				System.out.println("1.Red");
			        				System.out.println("2.Violet");
			        				System.out.println("===================");
			        				System.out.println(" ");
			        				System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
			        				System.out.print("Which Colour Your Prefer :");
			        				            //Switch For Colour Choosing 
			        							int WasColour2 =sc.nextInt();
			        							System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
			        							switch(WasColour2)
			        							{
			        							case 1:
			        									System.out.println(" ");
			        									System.out.println("Your Product Sir/Ma'am :"+vz.Username);
			        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
			        									WashingMachine m2 = new WashingMachine(789522,"Midea 6T Fully Automatic",10600,"Washing Machine","Red");
			        									m2.WashingMachineDetails();
			        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
			        									System.out.println(" ");
			        									System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
			        									System.out.println("============================");
			        									System.out.println("1.Purchase");
			        									System.out.println(" ");
			        									System.out.println("2.Exit");
			        									System.out.println("============================");
			        									System.out.print("Select Your Option :");
			        									          int purchase =sc.nextInt();
			        									          switch(purchase)
			        									          {
			        									          case 1:
			        									        	  System.out.println(" ");
			        									        	  vz.Delivery();
			        									          break;
			        									        	  
			        									          case 2:
			        									           System.out.println(" ");
			        									           System.out.println("Thank You For Visiting");
			        									           System.out.println("Plz Login Again If U Want To Purchase Something");
			        									           System.out.println(" ");
			        									           vz.login();
			        									           
			        									          default:
			                								          System.out.println(" ");
			                								          System.out.println("Invalid Macha Try Again");
			        									          
			        									          break;
			        									          }
			        			                break;//Product Colour 1
			        							case 2:
			        								System.out.println(" ");
			        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
			        								WashingMachine m3 = new WashingMachine(789522,"Midea 6T Fully Automatic",10800,"Washing Machine","Violet");
			        								m3.WashingMachineDetails();
			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
			        								System.out.println(" ");
			        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
			        								System.out.println("============================");
			        								System.out.println("1.Purchase");
			        								System.out.println(" ");
			        								System.out.println("2.Exit");
			        								System.out.println("============================");
			        								System.out.print("Select Your Option :");
			        								          int purchase2 =sc.nextInt();
			        								          switch(purchase2)
			        								          {
			        								          case 1:
			        								        	  System.out.println(" ");
			        								        	  vz.Delivery();
			        								          break;
			        								        	  
			        								          case 2:
			        								           System.out.println(" ");
			        								           System.out.println("Thank You For Visiting");
			        								           System.out.println("Plz Login Again If U Want To Purchase Something");
			        								           System.out.println(" ");
			        								           vz.login();
			        								           
			        								          default:
			            								          System.out.println(" ");
			            								          System.out.println("Invalid  Macha Try Again");
			        								           
			        								          break;
			        						     
			        								          }			        								          
			        							      break;//Product Colour 2
			        							      
			        							default:
	        								          System.out.println(" ");
	        								          System.out.println("Invalid Colour Macha Try Again");
	        								          
			        						   	}//Colour Close
			        							
			        				
			        		    break;////Midea 6T Fully Automatic End

			        			
			        			case 3://Whirlpool 9R Automatic With Dryer Start
			        				System.out.println(" ");
			        				System.out.println("⊱---------------------⊰");
			        				//long productId, String productName, double price, String category, String colour
			        				//Upcasting 
			        				Home m5 = new WashingMachine(789522,"Whirlpool 9R Automatic With Dryer",15600,"Washing Machine","Cyan or Black");
			        				m5.HomeDetails();
			        				System.out.println("⊱---------------------⊰");
			        				System.out.println(" ");
			        				System.out.println("Choose Your Colour");
			        				System.out.println("===================");
			        				System.out.println("1.Cyan");
			        				System.out.println("2.Black");
			        				System.out.println("===================");
			        				System.out.println(" ");
			        				System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
			        				System.out.print("Which Colour Your Prefer :");
			        				            //Switch For Colour Choosing 
			        							int WasColour3 =sc.nextInt();
			        							System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
			        							switch(WasColour3)
			        							{
			        							case 1:
			        									System.out.println(" ");
			        									System.out.println("Your Product Sir/Ma'am :"+vz.Username);
			        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
			        									WashingMachine m2 = new WashingMachine(789522,"Whirlpool 9R Automatic With Dryer",15600,"Washing Machine","Cyan");
			        									m2.WashingMachineDetails();
			        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
			        									System.out.println(" ");
			        									System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
			        									System.out.println("============================");
			        									System.out.println("1.Purchase");
			        									System.out.println(" ");
			        									System.out.println("2.Exit");
			        									System.out.println("============================");
			        									System.out.print("Select Your Option :");
			        									          int purchase =sc.nextInt();
			        									          switch(purchase)
			        									          {
			        									          case 1:
			        									        	  System.out.println(" ");
			        									        	  vz.Delivery();
			        									          break;
			        									        	  
			        									          case 2:
			        									           System.out.println(" ");
			        									           System.out.println("Thank You For Visiting");
			        									           System.out.println("Plz Login Again If U Want To Purchase Something");
			        									           System.out.println(" ");
			        									           vz.login();
			        									           
			        									          default:
			                								          System.out.println(" ");
			                								          System.out.println("Invalid  Macha Try Again");
			        									           
			        									          break;
			        									          }
			        			                break;//Product Colour 1
			        							case 2:
			        								System.out.println(" ");
			        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
			        								WashingMachine m3 = new WashingMachine(789522,"Whirlpool 9R Automatic With Dryer",15800,"Washing Machine","Black");
			        								m3.WashingMachineDetails();
			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
			        								System.out.println(" ");
			        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
			        								System.out.println("============================");
			        								System.out.println("1.Purchase");
			        								System.out.println(" ");
			        								System.out.println("2.Exit");
			        								System.out.println("============================");
			        								System.out.print("Select Your Option :");
			        								          int purchase2 =sc.nextInt();
			        								          switch(purchase2)
			        								          {
			        								          case 1:
			        								        	  System.out.println(" ");
			        								        	  vz.Delivery();
			        								          break;
			        								        	  
			        								          case 2:
			        								           System.out.println(" ");
			        								           System.out.println("Thank You For Visiting");
			        								           System.out.println("Plz Login Again If U Want To Purchase Something");
			        								           System.out.println(" ");
			        								           vz.login();
			        								          break;
			        								          
			        								          default:
			            								          System.out.println(" ");
			            								          System.out.println("Invalid  Macha Try Again");
			        						     
			        								          }			        								          
			        							      break;//Product Colour 2
			        							      
			        							default:
	        								          System.out.println(" ");
	        								          System.out.println("Invalid Colour Macha Try Again");
	        								          
			        						   	}//Colour Close
			        							
			        				
			        				break;//Whirlpool 9R Automatic With Dryer End

			        		    }
			        break;//Washing Machine End
			        
		            case 2://Air Conditioner Start
			            System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
			            System.out.println(" ");
			            System.out.println("Air Conditioner Section :");
			            System.out.println("========================");
				        System.out.println("1.Voltas 1.3 Ton 5 Star Inverter Split AC");
				        System.out.println(" ");
			            System.out.println("2.Samsung Ultima Series 1 Ton 3 Star Split AC");
			            System.out.println(" ");
			            System.out.println("3.Hisense Convertible 1 Ton 4 Star Split AC");
				        System.out.println("========================");
				        System.out.println(" ");
				        System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
				        System.out.print("Select Your Air Conditioner :");
				        int AirConditioner = sc.nextInt();
				        System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
				        switch (AirConditioner) 
				        {
				        			case 1://Voltas 1.3 Ton 5 Star Inverter Split AC Start
				        			System.out.println(" ");
				        			System.out.println("⊱---------------------⊰");
				        			//long productId, String productName, double price, String category, String colour
				        			//Upcasting 
				        			Home m1 = new AirConditioner(56652l,"Voltas 1.3 Ton 5 Star Inverter Split AC",26600,"Air Conditioner","Green or Maroon");
				        			m1.HomeDetails();
				        			System.out.println("⊱---------------------⊰");
				        			System.out.println(" ");
				        			System.out.println("Choose Your Colour");
				        			System.out.println("===================");
				        			System.out.println("1.Green");
				        			System.out.println("2.Maroon");
				        			System.out.println("===================");
				        			System.out.println(" ");
				        			System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
				        			System.out.print("Which Colour Your Prefer :");
				        			            //Switch For Colour Choosing 
				        						int WasColour =sc.nextInt();
				        						System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
				        						switch(WasColour)
				        						{
				        						case 1:
				        								System.out.println(" ");
				        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
				        								AirConditioner m2 = new AirConditioner(56652l,"Voltas 1.3 Ton 5 Star Inverter Split AC",26600,"Air Conditioner","Green");
				        								m2.AirConditionerDetails();
				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
				        								System.out.println(" ");
				        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
				        								System.out.println("============================");
				        								System.out.println("1.Purchase");
				        								System.out.println(" ");
				        								System.out.println("2.Exit");
				        								System.out.println("============================");
				        								System.out.print("Select Your Option :");
				        								          int purchase =sc.nextInt();
				        								          switch(purchase)
				        								          {
				        								          case 1:
				        								        	  System.out.println(" ");
				        								        	  vz.Delivery();
				        								          break;
				        								        	  
				        								          case 2:
				        								           System.out.println(" ");
				        								           System.out.println("Thank You For Visiting");
				        								           System.out.println("Plz Login Again If U Want To Purchase Something");
				        								           System.out.println(" ");
				        								           vz.login();
				        								           
				        								          default:
				            								          System.out.println(" ");
				            								          System.out.println("Invalid Macha Try Again");
				        								           
				        								          break;
				        								          }
				        		                break;//Product Colour 1
				        						case 2:
			        								System.out.println(" ");
			        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
			        								AirConditioner m3 = new AirConditioner(56652l,"Voltas 1.3 Ton 5 Star Inverter Split AC",26600,"Air Conditioner","Maroon");
			        								m3.AirConditionerDetails();
			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
			        								System.out.println(" ");
			        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
			        								System.out.println("============================");
			        								System.out.println("1.Purchase");
			        								System.out.println(" ");
			        								System.out.println("2.Exit");
			        								System.out.println("============================");
			        								System.out.print("Select Your Option :");
			        								          int purchase2 =sc.nextInt();
			        								          switch(purchase2)
			        								          {
			        								          case 1:
			        								        	  System.out.println(" ");
			        								        	  vz.Delivery();
			        								          break;
			        								        	  
			        								          case 2:
			        								           System.out.println(" ");
			        								           System.out.println("Thank You For Visiting");
			        								           System.out.println("Plz Login Again If U Want To Purchase Something");
			        								           System.out.println(" ");
			        								           vz.login();
			        								           
			        								          default:
			            								          System.out.println(" ");
			            								          System.out.println("Invalid Macha Try Again");
			        								           
			        								          break;
				        					     
			        								          }			        								          
				        						      break;//Product Colour 2
				        						      
				        						default:
	        								          System.out.println(" ");
	        								          System.out.println("Invalid Colour Macha Try Again");
				        						      
				        					   	}//Colour Close
				        						
				        			
				        			break;//Voltas 1.3 Ton 5 Star Inverter Split AC End
				        			
				        			case 2://Samsung Ultima Series 1 Ton 3 Star Split AC Start
				        				System.out.println(" ");
				        				System.out.println("⊱---------------------⊰");
				        				//long productId, String productName, double price, String category, String colour
				        				//Upcasting 
				        				Home m4 = new AirConditioner(566522,"Samsung Ultima Series 1 Ton 3 Star Split AC",50600,"Air Conditioner","Black or Pinky");
				        				m4.HomeDetails();
				        				System.out.println("⊱---------------------⊰");
				        				System.out.println(" ");
				        				System.out.println("Choose Your Colour");
				        				System.out.println("===================");
				        				System.out.println("1.Black");
				        				System.out.println("2.Pinky");
				        				System.out.println("===================");
				        				System.out.println(" ");
				        				System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
				        				System.out.print("Which Colour Your Prefer :");
				        				            //Switch For Colour Choosing 
				        							int WasColour2 =sc.nextInt();
				        							System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
				        							switch(WasColour2)
				        							{
				        							case 1:
				        									System.out.println(" ");
				        									System.out.println("Your Product Sir/Ma'am :"+vz.Username);
				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
				        									AirConditioner m2 = new AirConditioner(566522,"Samsung Ultima Series 1 Ton 3 Star Split AC",50600,"Air Conditioner","Black");
				        									m2.AirConditionerDetails();
				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
				        									System.out.println(" ");
				        									System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
				        									System.out.println("============================");
				        									System.out.println("1.Purchase");
				        									System.out.println(" ");
				        									System.out.println("2.Exit");
				        									System.out.println("============================");
				        									System.out.print("Select Your Option :");
				        									          int purchase =sc.nextInt();
				        									          switch(purchase)
				        									          {
				        									          case 1:
				        									        	  System.out.println(" ");
				        									        	  vz.Delivery();
				        									          break;
				        									        	  
				        									          case 2:
				        									           System.out.println(" ");
				        									           System.out.println("Thank You For Visiting");
				        									           System.out.println("Plz Login Again If U Want To Purchase Something");
				        									           System.out.println(" ");
				        									           vz.login();
				        									           
				        									          default:
				                								          System.out.println(" ");
				                								          System.out.println("Invalid  Macha Try Again");
				        									           
				        									          break;
				        									          }
				        			                break;//Product Colour 1
				        							case 2:
				        								System.out.println(" ");
				        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
				        								AirConditioner m3 = new AirConditioner(566522,"Samsung Ultima Series 1 Ton 3 Star Split AC",50600,"Air Conditioner","Pinky");
				        								m3.AirConditionerDetails();
				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
				        								System.out.println(" ");
				        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
				        								System.out.println("============================");
				        								System.out.println("1.Purchase");
				        								System.out.println(" ");
				        								System.out.println("2.Exit");
				        								System.out.println("============================");
				        								System.out.print("Select Your Option :");
				        								          int purchase2 =sc.nextInt();
				        								          switch(purchase2)
				        								          {
				        								          case 1:
				        								        	  System.out.println(" ");
				        								        	  vz.Delivery();
				        								          break;
				        								        	  
				        								          case 2:
				        								           System.out.println(" ");
				        								           System.out.println("Thank You For Visiting");
				        								           System.out.println("Plz Login Again If U Want To Purchase Something");
				        								           System.out.println(" ");
				        								           vz.login();
				        								           
				        								          default:
				            								          System.out.println(" ");
				            								          System.out.println("Invalid  Macha Try Again");
				        								           
				        								          break;
				        						     
				        								          }			        								          
				        							      break;//Product Colour 2
				        							      
				        							default:
		        								          System.out.println(" ");
		        								          System.out.println("Invalid Colour Macha Try Again");
		        								          
				        						   	}//Colour Close
				        							
				        				
				        		    break;//Samsung Ultima Series 1 Ton 3 Star Split AC End

				        			
				        			case 3://Hisense Convertible 1 Ton 4 Star Split AC Start
				        				System.out.println(" ");
				        				System.out.println("⊱---------------------⊰");
				        				//long productId, String productName, double price, String category, String colour
				        				//Upcasting 
				        				Home m5 = new AirConditioner(566523,"Hisense Convertible 1 Ton 4 Star Split AC",25600,"Air Conditioner","White or Blue");
				        				m5.HomeDetails();
				        				System.out.println("⊱---------------------⊰");
				        				System.out.println(" ");
				        				System.out.println("Choose Your Colour");
				        				System.out.println("===================");
				        				System.out.println("1.White");
				        				System.out.println("2.Blue");
				        				System.out.println("===================");
				        				System.out.println(" ");
				        				System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
				        				System.out.print("Which Colour Your Prefer :");
				        				            //Switch For Colour Choosing 
				        							int WasColour3 =sc.nextInt();
				        							System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
				        							switch(WasColour3)
				        							{
				        							case 1:
				        									System.out.println(" ");
				        									System.out.println("Your Product Sir/Ma'am :"+vz.Username);
				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
				        									AirConditioner m2 = new AirConditioner(566523,"Hisense Convertible 1 Ton 4 Star Split AC",25600,"Air Conditioner","White");
				        									m2.AirConditionerDetails();
				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
				        									System.out.println(" ");
				        									System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
				        									System.out.println("============================");
				        									System.out.println("1.Purchase");
				        									System.out.println(" ");
				        									System.out.println("2.Exit");
				        									System.out.println("============================");
				        									System.out.print("Select Your Option :");
				        									          int purchase =sc.nextInt();
				        									          switch(purchase)
				        									          {
				        									          case 1:
				        									        	  System.out.println(" ");
				        									        	  vz.Delivery();
				        									          break;
				        									        	  
				        									          case 2:
				        									           System.out.println(" ");
				        									           System.out.println("Thank You For Visiting");
				        									           System.out.println("Plz Login Again If U Want To Purchase Something");
				        									           System.out.println(" ");
				        									           vz.login();
				        									           
				        									          default:
				                								          System.out.println(" ");
				                								          System.out.println("Invalid Macha Try Again");
				        									           
				        									          break;
				        									          }
				        			                break;//Product Colour 1
				        							case 2:
				        								System.out.println(" ");
				        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
				        								AirConditioner m3 = new AirConditioner(566523,"Hisense Convertible 1 Ton 4 Star Split AC",25600,"Air Conditioner","Blue");
				        								m3.AirConditionerDetails();
				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
				        								System.out.println(" ");
				        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
				        								System.out.println("============================");
				        								System.out.println("1.Purchase");
				        								System.out.println(" ");
				        								System.out.println("2.Exit");
				        								System.out.println("============================");
				        								System.out.print("Select Your Option :");
				        								          int purchase2 =sc.nextInt();
				        								          switch(purchase2)
				        								          {
				        								          case 1:
				        								        	  System.out.println(" ");
				        								        	  vz.Delivery();
				        								          break;
				        								        	  
				        								          case 2:
				        								           System.out.println(" ");
				        								           System.out.println("Thank You For Visiting");
				        								           System.out.println("Plz Login Again If U Want To Purchase Something");
				        								           System.out.println(" ");
				        								           vz.login();
				        								           
				        								          default:
				            								          System.out.println(" ");
				            								          System.out.println("Invalid Macha Try Again");
				        								           
				        								          break;
				        						     
				        								          }			        								          
				        							      break;//Product Colour 2
				        							      
				        							default:
		        								          System.out.println(" ");
		        								          System.out.println("Invalid Colour Macha Try Again");
				        							      
				        						   	}//Colour Close
				        							
				        				
				        				break;//Hisense Convertible 1 Ton 4 Star Split AC End

				        		    }
				    break;//Air Conditioner End

	   
		            case 3://Refrigerators Start
			            System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
			            System.out.println(" ");
			            System.out.println("Refrigerators Section :");
			            System.out.println("========================");
				        System.out.println("1.Samsung 192 3-Star Direct Cool");
				        System.out.println(" ");
			            System.out.println("2.Haier 192  4-Star Direct Cool");
			            System.out.println(" ");
			            System.out.println("3.LG 190 5-Star Direct Cool");
				        System.out.println("========================");
				        System.out.println(" ");
				        System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
				        System.out.print("Select Your Refrigerators :");
				        int Refrigerators = sc.nextInt();
				        System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
				        switch (Refrigerators) 
				        {
				        			case 1://Samsung 192 3-Star Direct Cool Start
				        			System.out.println(" ");
				        			System.out.println("⊱---------------------⊰");
				        			//long productId, String productName, double price, String category, String colour
				        			//Upcasting 
				        			Home m6 = new Refrigerators(56052l,"Samsung 192 3-Star Direct Cool",25600,"Refrigerators","Yellow or Orange");
				        			m6.HomeDetails();
				        			System.out.println("⊱---------------------⊰");
				        			System.out.println(" ");
				        			System.out.println("Choose Your Colour");
				        			System.out.println("===================");
				        			System.out.println("1.Yellow");
				        			System.out.println("2.Orange");
				        			System.out.println("===================");
				        			System.out.println(" ");
				        			System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
				        			System.out.print("Which Colour Your Prefer :");
				        			            //Switch For Colour Choosing 
				        						int WasColour =sc.nextInt();
				        						System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
				        						switch(WasColour)
				        						{
				        						case 1:
				        								System.out.println(" ");
				        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
				        								Refrigerators m2 = new Refrigerators(56052l,"Samsung 192 3-Star Direct Cool",25600,"Refrigerators","Yellow");
				        								m2.RefrigeratorsDetails();
				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
				        								System.out.println(" ");
				        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
				        								System.out.println("============================");
				        								System.out.println("1.Purchase");
				        								System.out.println(" ");
				        								System.out.println("2.Exit");
				        								System.out.println("============================");
				        								System.out.print("Select Your Option :");
				        								          int purchase =sc.nextInt();
				        								          switch(purchase)
				        								          {
				        								          case 1:
				        								        	  System.out.println(" ");
				        								        	  vz.Delivery();
				        								          break;
				        								        	  
				        								          case 2:
				        								           System.out.println(" ");
				        								           System.out.println("Thank You For Visiting");
				        								           System.out.println("Plz Login Again If U Want To Purchase Something");
				        								           System.out.println(" ");
				        								           vz.login();
				        								           
				        								          default:
				            								          System.out.println(" ");
				            								          System.out.println("Invalid Macha Try Again");
				        								           
				        								          break;
				        								          }
				        		                break;//Product Colour 1
				        						case 2:
			        								System.out.println(" ");
			        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
			        								Refrigerators m3 = new Refrigerators(56052l,"Samsung 192 3-Star Direct Cool",25600,"Refrigerators","Orange");
			        								m3.RefrigeratorsDetails();
			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
			        								System.out.println(" ");
			        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
			        								System.out.println("============================");
			        								System.out.println("1.Purchase");
			        								System.out.println(" ");
			        								System.out.println("2.Exit");
			        								System.out.println("============================");
			        								System.out.print("Select Your Option :");
			        								          int purchase2 =sc.nextInt();
			        								          switch(purchase2)
			        								          {
			        								          case 1:
			        								        	  System.out.println(" ");
			        								        	  vz.Delivery();
			        								          break;
			        								        	  
			        								          case 2:
			        								           System.out.println(" ");
			        								           System.out.println("Thank You For Visiting");
			        								           System.out.println("Plz Login Again If U Want To Purchase Something");
			        								           System.out.println(" ");
			        								           vz.login();
			        								           
			        								          default:
			            								          System.out.println(" ");
			            								          System.out.println("Invalid Macha Try Again");
			        								           
			        								          break;
				        					     
			        								          }			        								          
				        						      break;//Product Colour 2
				        						      
				        						default:
	        								          System.out.println(" ");
	        								          System.out.println("Invalid Colour Macha Try Again");
				        						      
				        					   	}//Colour Close
				        						
				        			
				        			break;//Samsung 192 3-Star Direct Cool End
				        			
				        			case 2://Haier 192 4-Star Direct Cool Start
				        				System.out.println(" ");
				        				System.out.println("⊱---------------------⊰");
				        				//long productId, String productName, double price, String category, String colour
				        				//Upcasting 
				        				Home m4 = new Refrigerators(560522,"Haier 192 4-Star Direct Cool",29600,"Refrigerators","Green or Purple");
				        				m4.HomeDetails();
				        				System.out.println("⊱---------------------⊰");
				        				System.out.println(" ");
				        				System.out.println("Choose Your Colour");
				        				System.out.println("===================");
				        				System.out.println("1.Green");
				        				System.out.println("2.Purple");
				        				System.out.println("===================");
				        				System.out.println(" ");
				        				System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
				        				System.out.print("Which Colour Your Prefer :");
				        				            //Switch For Colour Choosing 
				        							int WasColour2 =sc.nextInt();
				        							System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
				        							switch(WasColour2)
				        							{
				        							case 1:
				        									System.out.println(" ");
				        									System.out.println("Your Product Sir/Ma'am :"+vz.Username);
				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
				        									Refrigerators m2 = new Refrigerators(560522,"Haier 192 4-Star Direct Cool",29600,"Refrigerators","Green");
				        									m2.RefrigeratorsDetails();
				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
				        									System.out.println(" ");
				        									System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
				        									System.out.println("============================");
				        									System.out.println("1.Purchase");
				        									System.out.println(" ");
				        									System.out.println("2.Exit");
				        									System.out.println("============================");
				        									System.out.print("Select Your Option :");
				        									          int purchase =sc.nextInt();
				        									          switch(purchase)
				        									          {
				        									          case 1:
				        									        	  System.out.println(" ");
				        									        	  vz.Delivery();
				        									          break;
				        									        	  
				        									          case 2:
				        									           System.out.println(" ");
				        									           System.out.println("Thank You For Visiting");
				        									           System.out.println("Plz Login Again If U Want To Purchase Something");
				        									           System.out.println(" ");
				        									           vz.login();
				        									           
				        									          default:
				                								          System.out.println(" ");
				                								          System.out.println("Invalid Macha Try Again");
				        									           
				        									          break;
				        									          }
				        			                break;//Product Colour 1
				        							case 2:
				        								System.out.println(" ");
				        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
				        								Refrigerators m3 = new Refrigerators(560522,"Haier 192 4-Star Direct Cool",29600,"Refrigerators","Purple");
				        								m3.RefrigeratorsDetails();
				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
				        								System.out.println(" ");
				        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
				        								System.out.println("============================");
				        								System.out.println("1.Purchase");
				        								System.out.println(" ");
				        								System.out.println("2.Exit");
				        								System.out.println("============================");
				        								System.out.print("Select Your Option :");
				        								          int purchase2 =sc.nextInt();
				        								          switch(purchase2)
				        								          {
				        								          case 1:
				        								        	  System.out.println(" ");
				        								        	  vz.Delivery();
				        								          break;
				        								        	  
				        								          case 2:
				        								           System.out.println(" ");
				        								           System.out.println("Thank You For Visiting");
				        								           System.out.println("Plz Login Again If U Want To Purchase Something");
				        								           System.out.println(" ");
				        								           vz.login();
				        								           
				        								          default:
				            								          System.out.println(" ");
				            								          System.out.println("Invalid Macha Try Again");
				        								           
				        								          break;
				        						     
				        								          }			        								          
				        							      break;//Product Colour 2
				        							      
				        							default:
		        								          System.out.println(" ");
		        								          System.out.println("Invalid Colour Macha Try Again");
				        							      
				        						   	}//Colour Close
				        							
				        				
				        		    break;//Haier 192 4-Star Direct Cool End

				        			
				        			case 3://LG 190 5-Star Direct Cool Start
				        				System.out.println(" ");
				        				System.out.println("⊱---------------------⊰");
				        				//long productId, String productName, double price, String category, String colour
				        				//Upcasting 
				        				Home m5 = new Refrigerators(560523,"LG 190 5-Star Direct Cool",27600,"Refrigerators","White or Navy Blue");
				        				m5.HomeDetails();
				        				System.out.println("⊱---------------------⊰");
				        				System.out.println(" ");
				        				System.out.println("Choose Your Colour");
				        				System.out.println("===================");
				        				System.out.println("1.White");
				        				System.out.println("2.Navy Blue");
				        				System.out.println("===================");
				        				System.out.println(" ");
				        				System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
				        				System.out.print("Which Colour Your Prefer :");
				        				            //Switch For Colour Choosing 
				        							int WasColour3 =sc.nextInt();
				        							System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
				        							switch(WasColour3)
				        							{
				        							case 1:
				        									System.out.println(" ");
				        									System.out.println("Your Product Sir/Ma'am :"+vz.Username);
				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
				        									Refrigerators m2 = new Refrigerators(560523,"LG 190 5-Star Direct Cool",27600,"Refrigerators","White");
				        									m2.RefrigeratorsDetails();
				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
				        									System.out.println(" ");
				        									System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
				        									System.out.println("============================");
				        									System.out.println("1.Purchase");
				        									System.out.println(" ");
				        									System.out.println("2.Exit");
				        									System.out.println("============================");
				        									System.out.print("Select Your Option :");
				        									          int purchase =sc.nextInt();
				        									          switch(purchase)
				        									          {
				        									          case 1:
				        									        	  System.out.println(" ");
				        									        	  vz.Delivery();
				        									          break;
				        									        	  
				        									          case 2:
				        									           System.out.println(" ");
				        									           System.out.println("Thank You For Visiting");
				        									           System.out.println("Plz Login Again If U Want To Purchase Something");
				        									           System.out.println(" ");
				        									           vz.login();
				        									           
				        									          default:
				                								          System.out.println(" ");
				                								          System.out.println("Invalid Macha Try Again");
				        									           
				        									          break;
				        									          }
				        			                break;//Product Colour 1
				        							case 2:
				        								System.out.println(" ");
				        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
				        								Refrigerators m3 = new Refrigerators(560523,"LG 190 5-Star Direct Cool",27600,"Refrigerators","Navy Blue");
				        								m3.RefrigeratorsDetails();
				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
				        								System.out.println(" ");
				        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
				        								System.out.println("============================");
				        								System.out.println("1.Purchase");
				        								System.out.println(" ");
				        								System.out.println("2.Exit");
				        								System.out.println("============================");
				        								System.out.print("Select Your Option :");
				        								          int purchase2 =sc.nextInt();
				        								          switch(purchase2)
				        								          {
				        								          case 1:
				        								        	  System.out.println(" ");
				        								        	  vz.Delivery();
				        								          break;
				        								        	  
				        								          case 2:
				        								           System.out.println(" ");
				        								           System.out.println("Thank You For Visiting");
				        								           System.out.println("Plz Login Again If U Want To Purchase Something");
				        								           System.out.println(" ");
				        								           vz.login();
				        								           
				        								          default:
				            								          System.out.println(" ");
				            								          System.out.println("Invalid Macha Try Again");
				        								          break;
				        						     
				        								          }			        								          
				        							      break;//Product Colour 2
				        							      
				        							default:
		        								          System.out.println(" ");
		        								          System.out.println("Invalid Colour Macha Try Again");
				        							      
				        						   	}//Colour Close
				        							
				        				
				        				break;//LG 190 5-Star Direct Cool End

				        		    }
				        break;//Refrigerators End
				        
		            default:
				          System.out.println(" ");
				          System.out.println("Invalid Home Appliances Macha Try Again");


		      }
		
      break;
      //------------------------------------Home Appliances End Switch------------------------------------//
      
      
			
    //------------------------------------Kitchen Appliances Start Switch------------------------------------//
    		case 2:
    		System.out.println("Your Selected Category: Kitchen Appliances");
    		System.out.println(" ");
    		System.out.println("Kitchen Appliances Category Sections :");
    		System.out.println("========================");
    		System.out.println("1.Electric Chimneys");
    		System.out.println(" ");
    		System.out.println("2.Dish Washers");
    		System.out.println(" ");
    		System.out.println("3.Water Purifiers");
    		System.out.println("========================");
    		System.out.println(" ");
    		System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    		System.out.print("Select the Appliances :");
    		int KitchenAppliances = sc.nextInt();
    		     switch (KitchenAppliances) 
    		     {
    		
    		            case 1://Electric Chimneys Start
    		            System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    		            System.out.println(" ");
    		            System.out.println("Electric Chimneys Section :");
    		            System.out.println("========================");
    			        System.out.println("1.Elica 900 NERO");
    			        System.out.println(" ");
    			        System.out.println("2.Faber Hood Alpha HC 1100");
    			        System.out.println(" ");
    			        System.out.println("3.KAFF 1000N Mount Chimney");
    			        System.out.println("========================");
    			        System.out.println(" ");
    			        System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    			        System.out.print("Select Your Electric Chimneys :");
    			        int ElectricChimneys = sc.nextInt();
    			        System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    			        switch (ElectricChimneys) 
    			        {
    			        			case 1://Elica 900 NERO Start
    			        			System.out.println(" ");
    			        			System.out.println("⊱---------------------⊰");
    			        			//long productId, String productName, double price, String category, String colour
    			        			//Upcasting 
    			        			Kitchen m1 = new ElectricChimneys(78952,"Elica 900 NERO",9200,"Electric Chimneys","Grey & Yellow");
    			        			m1.KitchenDetails();
    			        			System.out.println("⊱---------------------⊰");
    			        			System.out.println(" ");
    			        			System.out.println("Choose Your Colour");
    			        			System.out.println("===================");
    			        			System.out.println("1.Grey");
    			        			System.out.println("2.Yellow");
    			        			System.out.println("===================");
    			        			System.out.println(" ");
    			        			System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    			        			System.out.print("Which Colour Your Prefer :");
    			        			            //Switch For Colour Choosing 
    			        						int WasColour =sc.nextInt();
    			        						System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    			        						switch(WasColour)
    			        						{
    			        						case 1:
    			        								System.out.println(" ");
    			        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
    			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    			        								ElectricChimneys m2 = new ElectricChimneys(78952,"Elica 900 NERO",9200,"Electric Chimneys","Grey");
    			        								m2.ElectricChimneysDetails();
    			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    			        								System.out.println(" ");
    			        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
    			        								System.out.println("============================");
    			        								System.out.println("1.Purchase");
    			        								System.out.println(" ");
    			        								System.out.println("2.Exit");
    			        								System.out.println("============================");
    			        								System.out.print("Select Your Option :");
    			        								          int purchase =sc.nextInt();
    			        								          switch(purchase)
    			        								          {
    			        								          case 1:
    			        								        	  System.out.println(" ");
    			        								        	  vz.Delivery();
    			        								          break;
    			        								        	  
    			        								          case 2:
    			        								           System.out.println(" ");
    			        								           System.out.println("Thank You For Visiting");
    			        								           System.out.println("Plz Login Again If U Want To Purchase Something");
    			        								           System.out.println(" ");
    			        								           vz.login();
    			        								          break;

    			        								          default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Macha Try Again");
    			        								          }
    			        		                break;//Product Colour 1
    			        						case 2:
    		        								System.out.println(" ");
    		        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
    		        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    		        								ElectricChimneys m3 = new ElectricChimneys(78952,"Elica 900 NERO",9200,"Electric Chimneys","Yellow");
    		        								m3.ElectricChimneysDetails();
    		        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    		        								System.out.println(" ");
    		        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
    		        								System.out.println("============================");
    		        								System.out.println("1.Purchase");
    		        								System.out.println(" ");
    		        								System.out.println("2.Exit");
    		        								System.out.println("============================");
    		        								System.out.print("Select Your Option :");
    		        								          int purchase2 =sc.nextInt();
    		        								          switch(purchase2)
    		        								          {
    		        								          case 1:
    		        								        	  System.out.println(" ");
    		        								        	  vz.Delivery();
    		        								          break;
    		        								        	  
    		        								          case 2:
    		        								           System.out.println(" ");
    		        								           System.out.println("Thank You For Visiting");
    		        								           System.out.println("Plz Login Again If U Want To Purchase Something");
    		        								           System.out.println(" ");
    		        								           vz.login();
    		        								          break;


    		        								          default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Macha Try Again");
    			        					     
    		        								          }			        								          
    			        						      break;//Product Colour 2
    			        						     default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Colour Macha Try Again");
    			        					   	}//Colour Close
    			        						
    			        			
    			        			break;//Elica 900 NERO End
    			        			
    			        			case 2://Faber Hood Alpha HC 1100 Start
    			        				System.out.println(" ");
    			        				System.out.println("⊱---------------------⊰");
    			        				//long productId, String productName, double price, String category, String colour
    			        				//Upcasting 
    			        				Kitchen m4 = new ElectricChimneys(789522,"Faber Hood Alpha HC 1100",10600,"Electric Chimneys","Red Or Violet");
    			        				m4.KitchenDetails();
    			        				System.out.println("⊱---------------------⊰");
    			        				System.out.println(" ");
    			        				System.out.println("Choose Your Colour");
    			        				System.out.println("===================");
    			        				System.out.println("1.Red");
    			        				System.out.println("2.Violet");
    			        				System.out.println("===================");
    			        				System.out.println(" ");
    			        				System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    			        				System.out.print("Which Colour Your Prefer :");
    			        				            //Switch For Colour Choosing 
    			        							int WasColour2 =sc.nextInt();
    			        							System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    			        							switch(WasColour2)
    			        							{
    			        							case 1:
    			        									System.out.println(" ");
    			        									System.out.println("Your Product Sir/Ma'am :"+vz.Username);
    			        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    			        									ElectricChimneys m2 = new ElectricChimneys(789522,"Faber Hood Alpha HC 1100",10600,"Electric Chimneys","Red");
    			        									m2.ElectricChimneysDetails();
    			        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    			        									System.out.println(" ");
    			        									System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
    			        									System.out.println("============================");
    			        									System.out.println("1.Purchase");
    			        									System.out.println(" ");
    			        									System.out.println("2.Exit");
    			        									System.out.println("============================");
    			        									System.out.print("Select Your Option :");
    			        									          int purchase =sc.nextInt();
    			        									          switch(purchase)
    			        									          {
    			        									          case 1:
    			        									        	  System.out.println(" ");
    			        									        	  vz.Delivery();
    			        									          break;
    			        									        	  
    			        									          case 2:
    			        									           System.out.println(" ");
    			        									           System.out.println("Thank You For Visiting");
    			        									           System.out.println("Plz Login Again If U Want To Purchase Something");
    			        									           System.out.println(" ");
    			        									           vz.login();
    			        									          break;
    			        									          default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Macha Try Again");
    			        									          }
    			        			                break;//Product Colour 1
    			        							case 2:
    			        								System.out.println(" ");
    			        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
    			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    			        								ElectricChimneys m3 = new ElectricChimneys(789522,"Faber Hood Alpha HC 1100",10800,"Electric Chimneys","Violet");
    			        								m3.ElectricChimneysDetails();
    			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    			        								System.out.println(" ");
    			        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
    			        								System.out.println("============================");
    			        								System.out.println("1.Purchase");
    			        								System.out.println(" ");
    			        								System.out.println("2.Exit");
    			        								System.out.println("============================");
    			        								System.out.print("Select Your Option :");
    			        								          int purchase2 =sc.nextInt();
    			        								          switch(purchase2)
    			        								          {
    			        								          case 1:
    			        								        	  System.out.println(" ");
    			        								        	  vz.Delivery();
    			        								          break;
    			        								        	  
    			        								          case 2:
    			        								           System.out.println(" ");
    			        								           System.out.println("Thank You For Visiting");
    			        								           System.out.println("Plz Login Again If U Want To Purchase Something");
    			        								           System.out.println(" ");
    			        								           vz.login();
    			        								          break;

    			        								          default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Macha Try Again");
    			        						     
    			        								          }			        								          
    			        							      break;//Product Colour 2

    			        							     default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Colour Macha Try Again");
    			        						   	}//Colour Close
    			        							
    			        				
    			        		    break;////Faber Hood Alpha HC 1100 End

    			        			
    			        			case 3://KAFF 1000N Mount Chimney Start
    			        				System.out.println(" ");
    			        				System.out.println("⊱---------------------⊰");
    			        				//long productId, String productName, double price, String category, String colour
    			        				//Upcasting 
    			        				Kitchen m5 = new ElectricChimneys(789522,"KAFF 1000N Mount Chimney",15600,"Electric Chimneys","Cyan or Black");
    			        				m5.KitchenDetails();
    			        				System.out.println("⊱---------------------⊰");
    			        				System.out.println(" ");
    			        				System.out.println("Choose Your Colour");
    			        				System.out.println("===================");
    			        				System.out.println("1.Cyan");
    			        				System.out.println("2.Black");
    			        				System.out.println("===================");
    			        				System.out.println(" ");
    			        				System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    			        				System.out.print("Which Colour Your Prefer :");
    			        				            //Switch For Colour Choosing 
    			        							int WasColour3 =sc.nextInt();
    			        							System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    			        							switch(WasColour3)
    			        							{
    			        							case 1:
    			        									System.out.println(" ");
    			        									System.out.println("Your Product Sir/Ma'am :"+vz.Username);
    			        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    			        									ElectricChimneys m2 = new ElectricChimneys(789522,"KAFF 1000N Mount Chimney",15600,"Electric Chimneys","Cyan");
    			        									m2.ElectricChimneysDetails();
    			        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    			        									System.out.println(" ");
    			        									System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
    			        									System.out.println("============================");
    			        									System.out.println("1.Purchase");
    			        									System.out.println(" ");
    			        									System.out.println("2.Exit");
    			        									System.out.println("============================");
    			        									System.out.print("Select Your Option :");
    			        									          int purchase =sc.nextInt();
    			        									          switch(purchase)
    			        									          {
    			        									          case 1:
    			        									        	  System.out.println(" ");
    			        									        	  vz.Delivery();
    			        									          break;
    			        									        	  
    			        									          case 2:
    			        									           System.out.println(" ");
    			        									           System.out.println("Thank You For Visiting");
    			        									           System.out.println("Plz Login Again If U Want To Purchase Something");
    			        									           System.out.println(" ");
    			        									           vz.login();
    			        									          break;

    			        									          default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Macha Try Again");
    			        									          }
    			        			                break;//Product Colour 1
    			        							case 2:
    			        								System.out.println(" ");
    			        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
    			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    			        								ElectricChimneys m3 = new ElectricChimneys(789522,"KAFF 1000N Mount Chimney",15800,"Electric Chimneys","Black");
    			        								m3.ElectricChimneysDetails();
    			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    			        								System.out.println(" ");
    			        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
    			        								System.out.println("============================");
    			        								System.out.println("1.Purchase");
    			        								System.out.println(" ");
    			        								System.out.println("2.Exit");
    			        								System.out.println("============================");
    			        								System.out.print("Select Your Option :");
    			        								          int purchase2 =sc.nextInt();
    			        								          switch(purchase2)
    			        								          {
    			        								          case 1:
    			        								        	  System.out.println(" ");
    			        								        	  vz.Delivery();
    			        								          break;
    			        								        	  
    			        								          case 2:
    			        								           System.out.println(" ");
    			        								           System.out.println("Thank You For Visiting");
    			        								           System.out.println("Plz Login Again If U Want To Purchase Something");
    			        								           System.out.println(" ");
    			        								           vz.login();
    			        								          break;

    			        								          default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Macha Try Again");
    			        						     
    			        								          }			        								          
    			        							      break;//Product Colour 2

    			        							      default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Colour Macha Try Again");
    			        						   	}//Colour Close
    			        							
    			        				
    			        				break;//KAFF 1000N Mount Chimney End

    			        		    }
    			        break;//Electric Chimneys End
    			        
    		            case 2://Dish Washers Start
    			            System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    			            System.out.println(" ");
    			            System.out.println("Dish Washers Section :");
    			            System.out.println("========================");
    				        System.out.println("1.Voltas Beko 14 Place Dish Washers");
    				        System.out.println(" ");
    			            System.out.println("2.Toshiba 14 Place Setting DWToshiba 14 Place Setting DW");
    			            System.out.println(" ");
    			            System.out.println("3.Samsung IntensiveWash 13 DW");
    				        System.out.println("========================");
    				        System.out.println(" ");
    				        System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    				        System.out.print("Select Your Dish Washers :");
    				        int DishWashers = sc.nextInt();
    				        System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    				        switch (DishWashers) 
    				        {
    				        			case 1://Voltas Beko 14 Place Dish Washers Start
    				        			System.out.println(" ");
    				        			System.out.println("⊱---------------------⊰");
    				        			//long productId, String productName, double price, String category, String colour
    				        			//Upcasting 
    				        			Kitchen m1 = new DishWashers(56652l,"Voltas Beko 14 Place Dish Washers",26600,"Dish Washers","Green or Maroon");
    				        			m1.KitchenDetails();
    				        			System.out.println("⊱---------------------⊰");
    				        			System.out.println(" ");
    				        			System.out.println("Choose Your Colour");
    				        			System.out.println("===================");
    				        			System.out.println("1.Green");
    				        			System.out.println("2.Maroon");
    				        			System.out.println("===================");
    				        			System.out.println(" ");
    				        			System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    				        			System.out.print("Which Colour Your Prefer :");
    				        			            //Switch For Colour Choosing 
    				        						int WasColour =sc.nextInt();
    				        						System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    				        						switch(WasColour)
    				        						{
    				        						case 1:
    				        								System.out.println(" ");
    				        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
    				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    				        								DishWashers m2 = new DishWashers(56652l,"Voltas Beko 14 Place Dish Washers",26600,"Dish Washers","Green");
    				        								m2.DishWashersDetails();
    				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    				        								System.out.println(" ");
    				        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
    				        								System.out.println("============================");
    				        								System.out.println("1.Purchase");
    				        								System.out.println(" ");
    				        								System.out.println("2.Exit");
    				        								System.out.println("============================");
    				        								System.out.print("Select Your Option :");
    				        								          int purchase =sc.nextInt();
    				        								          switch(purchase)
    				        								          {
    				        								          case 1:
    				        								        	  System.out.println(" ");
    				        								        	  vz.Delivery();
    				        								          break;
    				        								        	  
    				        								          case 2:
    				        								           System.out.println(" ");
    				        								           System.out.println("Thank You For Visiting");
    				        								           System.out.println("Plz Login Again If U Want To Purchase Something");
    				        								           System.out.println(" ");
    				        								           vz.login();
    				        								          break;


    				        								           default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Macha Try Again");

    				        								          }
    				        		                break;//Product Colour 1
    				        						case 2:
    			        								System.out.println(" ");
    			        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
    			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    			        								DishWashers m3 = new DishWashers(56652l,"Voltas Beko 14 Place Dish Washers",26600,"Dish Washers","Maroon");
    			        								m3.DishWashersDetails();
    			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    			        								System.out.println(" ");
    			        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
    			        								System.out.println("============================");
    			        								System.out.println("1.Purchase");
    			        								System.out.println(" ");
    			        								System.out.println("2.Exit");
    			        								System.out.println("============================");
    			        								System.out.print("Select Your Option :");
    			        								          int purchase2 =sc.nextInt();
    			        								          switch(purchase2)
    			        								          {
    			        								          case 1:
    			        								        	  System.out.println(" ");
    			        								        	  vz.Delivery();
    			        								          break;
    			        								        	  
    			        								          case 2:
    			        								           System.out.println(" ");
    			        								           System.out.println("Thank You For Visiting");
    			        								           System.out.println("Plz Login Again If U Want To Purchase Something");
    			        								           System.out.println(" ");
    			        								           vz.login();
    			        								          break;

    			        								           default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Macha Try Again");
    				        					     
    			        								          }			        								          
    				        						      break;//Product Colour 2

    				        						       default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Colour Macha Try Again");
    				        					   	}//Colour Close
    				        						
    				        			
    				        			break;//Voltas Beko 14 Place Dish Washers End
    				        			
    				        			case 2://Toshiba 14 Place Setting DW Start
    				        				System.out.println(" ");
    				        				System.out.println("⊱---------------------⊰");
    				        				//long productId, String productName, double price, String category, String colour
    				        				//Upcasting 
    				        				Kitchen m4 = new DishWashers(566522,"Toshiba 14 Place Setting DW",50600,"Dish Washers","Black or Pinky");
    				        				m4.KitchenDetails();
    				        				System.out.println("⊱---------------------⊰");
    				        				System.out.println(" ");
    				        				System.out.println("Choose Your Colour");
    				        				System.out.println("===================");
    				        				System.out.println("1.Black");
    				        				System.out.println("2.Pinky");
    				        				System.out.println("===================");
    				        				System.out.println(" ");
    				        				System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    				        				System.out.print("Which Colour Your Prefer :");
    				        				            //Switch For Colour Choosing 
    				        							int WasColour2 =sc.nextInt();
    				        							System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    				        							switch(WasColour2)
    				        							{
    				        							case 1:
    				        									System.out.println(" ");
    				        									System.out.println("Your Product Sir/Ma'am :"+vz.Username);
    				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    				        									DishWashers m2 = new DishWashers(566522,"Toshiba 14 Place Setting DW",50600,"Dish Washers","Black");
    				        									m2.DishWashersDetails();
    				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    				        									System.out.println(" ");
    				        									System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
    				        									System.out.println("============================");
    				        									System.out.println("1.Purchase");
    				        									System.out.println(" ");
    				        									System.out.println("2.Exit");
    				        									System.out.println("============================");
    				        									System.out.print("Select Your Option :");
    				        									          int purchase =sc.nextInt();
    				        									          switch(purchase)
    				        									          {
    				        									          case 1:
    				        									        	  System.out.println(" ");
    				        									        	  vz.Delivery();
    				        									          break;
    				        									        	  
    				        									          case 2:
    				        									           System.out.println(" ");
    				        									           System.out.println("Thank You For Visiting");
    				        									           System.out.println("Plz Login Again If U Want To Purchase Something");
    				        									           System.out.println(" ");
    				        									           vz.login();
    				        									          break;


    				        									           default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Macha Try Again");

    				        									          }
    				        			                break;//Product Colour 1
    				        							case 2:
    				        								System.out.println(" ");
    				        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
    				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    				        								DishWashers m3 = new DishWashers(566522,"Toshiba 14 Place Setting DW",50600,"Dish Washers","Pinky");
    				        								m3.DishWashersDetails();
    				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    				        								System.out.println(" ");
    				        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
    				        								System.out.println("============================");
    				        								System.out.println("1.Purchase");
    				        								System.out.println(" ");
    				        								System.out.println("2.Exit");
    				        								System.out.println("============================");
    				        								System.out.print("Select Your Option :");
    				        								          int purchase2 =sc.nextInt();
    				        								          switch(purchase2)
    				        								          {
    				        								          case 1:
    				        								        	  System.out.println(" ");
    				        								        	  vz.Delivery();
    				        								          break;
    				        								        	  
    				        								          case 2:
    				        								           System.out.println(" ");
    				        								           System.out.println("Thank You For Visiting");
    				        								           System.out.println("Plz Login Again If U Want To Purchase Something");
    				        								           System.out.println(" ");
    				        								           vz.login();
    				        								          break;


    				        								           default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Macha Try Again");
    				        						     
    				        								          }			        								          
    				        							      break;//Product Colour 2

    				        							       default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Colour Macha Try Again");
    				        						   	}//Colour Close
    				        							
    				        				
    				        		    break;//Toshiba 14 Place Setting DW End

    				        			
    				        			case 3://Samsung IntensiveWash 13 DW Start
    				        				System.out.println(" ");
    				        				System.out.println("⊱---------------------⊰");
    				        				//long productId, String productName, double price, String category, String colour
    				        				//Upcasting 
    				        				Kitchen m5 = new DishWashers(566523,"Samsung IntensiveWash 13 DW",25600,"Dish Washers","White or Blue");
    				        				m5.KitchenDetails();
    				        				System.out.println("⊱---------------------⊰");
    				        				System.out.println(" ");
    				        				System.out.println("Choose Your Colour");
    				        				System.out.println("===================");
    				        				System.out.println("1.White");
    				        				System.out.println("2.Blue");
    				        				System.out.println("===================");
    				        				System.out.println(" ");
    				        				System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    				        				System.out.print("Which Colour Your Prefer :");
    				        				            //Switch For Colour Choosing 
    				        							int WasColour3 =sc.nextInt();
    				        							System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    				        							switch(WasColour3)
    				        							{
    				        							case 1:
    				        									System.out.println(" ");
    				        									System.out.println("Your Product Sir/Ma'am :"+vz.Username);
    				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    				        									DishWashers m2 = new DishWashers(566523,"Samsung IntensiveWash 13 DW",25600,"Dish Washers","White");
    				        									m2.DishWashersDetails();
    				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    				        									System.out.println(" ");
    				        									System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
    				        									System.out.println("============================");
    				        									System.out.println("1.Purchase");
    				        									System.out.println(" ");
    				        									System.out.println("2.Exit");
    				        									System.out.println("============================");
    				        									System.out.print("Select Your Option :");
    				        									          int purchase =sc.nextInt();
    				        									          switch(purchase)
    				        									          {
    				        									          case 1:
    				        									        	  System.out.println(" ");
    				        									        	  vz.Delivery();
    				        									          break;
    				        									        	  
    				        									          case 2:
    				        									           System.out.println(" ");
    				        									           System.out.println("Thank You For Visiting");
    				        									           System.out.println("Plz Login Again If U Want To Purchase Something");
    				        									           System.out.println(" ");
    				        									           vz.login();
    				        									          break;

    				        									           default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Macha Try Again");
    				        									          }
    				        			                break;//Product Colour 1
    				        							case 2:
    				        								System.out.println(" ");
    				        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
    				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    				        								DishWashers m3 = new DishWashers(566523,"Samsung IntensiveWash 13 DW",25600,"Dish Washers","Blue");
    				        								m3.DishWashersDetails();
    				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    				        								System.out.println(" ");
    				        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
    				        								System.out.println("============================");
    				        								System.out.println("1.Purchase");
    				        								System.out.println(" ");
    				        								System.out.println("2.Exit");
    				        								System.out.println("============================");
    				        								System.out.print("Select Your Option :");
    				        								          int purchase2 =sc.nextInt();
    				        								          switch(purchase2)
    				        								          {
    				        								          case 1:
    				        								        	  System.out.println(" ");
    				        								        	  vz.Delivery();
    				        								          break;
    				        								        	  
    				        								          case 2:
    				        								           System.out.println(" ");
    				        								           System.out.println("Thank You For Visiting");
    				        								           System.out.println("Plz Login Again If U Want To Purchase Something");
    				        								           System.out.println(" ");
    				        								           vz.login();
    				        								          break;


    				        								           default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Macha Try Again");
    				        						     
    				        								          }			        				          
    				        							      break;//Product Colour 2

    				        							       default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Colour Macha Try Again");
    				        						   	}//Colour Close
    				        							
    				        				
    				        				break;//Samsung IntensiveWash 13 DW End

    				        		    }
    				    break;//Dish Washers End

    	   
    		            case 3://Water Purifiers Start
    			            System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    			            System.out.println(" ");
    			            System.out.println("Water Purifiers Section :");
    			            System.out.println("========================");
    				        System.out.println("1.Kent Grand Plus RO+UV+UF+TDS Electrical Water Purifier");
    				        System.out.println(" ");
    			            System.out.println("2.AO Smith ProPlanet P4 RO+SCMT+UV LED Electrical Water Purifier");
    			            System.out.println(" ");
    			            System.out.println("3.Aquaguard Crystal NXT Water Purifier");
    				        System.out.println("========================");
    				        System.out.println(" ");
    				        System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    				        System.out.print("Select Your Water Purifiers :");
    				        int WaterPurifiers = sc.nextInt();
    				        System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    				        switch (WaterPurifiers) 
    				        {
    				        			case 1://Kent Grand Plus RO+UV+UF+TDS Electrical Water Purifier Start
    				        			System.out.println(" ");
    				        			System.out.println("⊱---------------------⊰");
    				        			//long productId, String productName, double price, String category, String colour
    				        			//Upcasting 
    				        			Kitchen m6 = new WaterPurifiers(56052l,"Kent Grand Plus RO+UV+UF+TDS Electrical Water Purifier",25600,"Water Purifiers","Yellow or Orange");
    				        			m6.KitchenDetails();
    				        			System.out.println("⊱---------------------⊰");
    				        			System.out.println(" ");
    				        			System.out.println("Choose Your Colour");
    				        			System.out.println("===================");
    				        			System.out.println("1.Yellow");
    				        			System.out.println("2.Orange");
    				        			System.out.println("===================");
    				        			System.out.println(" ");
    				        			System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    				        			System.out.print("Which Colour Your Prefer :");
    				        			            //Switch For Colour Choosing 
    				        						int WasColour =sc.nextInt();
    				        						System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    				        						switch(WasColour)
    				        						{
    				        						case 1:
    				        								System.out.println(" ");
    				        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
    				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    				        								WaterPurifiers m2 = new WaterPurifiers(56052l,"Kent Grand Plus RO+UV+UF+TDS Electrical Water Purifier",25600,"Water Purifiers","Yellow");
    				        								m2.WaterPurifiersDetails();
    				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    				        								System.out.println(" ");
    				        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
    				        								System.out.println("============================");
    				        								System.out.println("1.Purchase");
    				        								System.out.println(" ");
    				        								System.out.println("2.Exit");
    				        								System.out.println("============================");
    				        								System.out.print("Select Your Option :");
    				        								          int purchase =sc.nextInt();
    				        								          switch(purchase)
    				        								          {
    				        								          case 1:
    				        								        	  System.out.println(" ");
    				        								        	  vz.Delivery();
    				        								          break;
    				        								        	  
    				        								          case 2:
    				        								           System.out.println(" ");
    				        								           System.out.println("Thank You For Visiting");
    				        								           System.out.println("Plz Login Again If U Want To Purchase Something");
    				        								           System.out.println(" ");
    				        								           vz.login();
    				        								          break;
    				        								           default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Macha Try Again");
    				        								          }
    				        		                break;//Product Colour 1
    				        						case 2:
    			        								System.out.println(" ");
    			        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
    			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    			        								WaterPurifiers m3 = new WaterPurifiers(56052l,"Kent Grand Plus RO+UV+UF+TDS Electrical Water Purifier",25600,"Water Purifiers","Orange");
    			        								m3.WaterPurifiersDetails();
    			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    			        								System.out.println(" ");
    			        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
    			        								System.out.println("============================");
    			        								System.out.println("1.Purchase");
    			        								System.out.println(" ");
    			        								System.out.println("2.Exit");
    			        								System.out.println("============================");
    			        								System.out.print("Select Your Option :");
    			        								          int purchase2 =sc.nextInt();
    			        								          switch(purchase2)
    			        								          {
    			        								          case 1:
    			        								        	  System.out.println(" ");
    			        								        	  vz.Delivery();
    			        								          break;
    			        								        	  
    			        								          case 2:
    			        								           System.out.println(" ");
    			        								           System.out.println("Thank You For Visiting");
    			        								           System.out.println("Plz Login Again If U Want To Purchase Something");
    			        								           System.out.println(" ");
    			        								           vz.login();
    			        								          break;
    			        								       default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid  Macha Try Again");
    				        					     
    			        								          }			        								          
    				        						      break;//Product Colour 2

    				        						       default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Colour Macha Try Again");
    				        					   	}//Colour Close
    				        						
    				        			
    				        			break;//Kent Grand Plus RO+UV+UF+TDS Electrical Water Purifier End
    				        			
    				        			case 2://AO Smith ProPlanet P4 RO+SCMT+UV LED Electrical Water Purifier Start
    				        				System.out.println(" ");
    				        				System.out.println("⊱---------------------⊰");
    				        				//long productId, String productName, double price, String category, String colour
    				        				//Upcasting 
    				        				Kitchen m4 = new WaterPurifiers(560522,"AO Smith ProPlanet P4 RO+SCMT+UV LED Electrical Water Purifier",29600,"Water Purifiers","Green or Purple");
    				        				m4.KitchenDetails();
    				        				System.out.println("⊱---------------------⊰");
    				        				System.out.println(" ");
    				        				System.out.println("Choose Your Colour");
    				        				System.out.println("===================");
    				        				System.out.println("1.Green");
    				        				System.out.println("2.Purple");
    				        				System.out.println("===================");
    				        				System.out.println(" ");
    				        				System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    				        				System.out.print("Which Colour Your Prefer :");
    				        				            //Switch For Colour Choosing 
    				        							int WasColour2 =sc.nextInt();
    				        							System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    				        							switch(WasColour2)
    				        							{
    				        							case 1:
    				        									System.out.println(" ");
    				        									System.out.println("Your Product Sir/Ma'am :"+vz.Username);
    				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    				        									WaterPurifiers m2 = new WaterPurifiers(560522,"AO Smith ProPlanet P4 RO+SCMT+UV LED Electrical Water Purifier",29600,"Water Purifiers","Green");
    				        									m2.WaterPurifiersDetails();
    				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    				        									System.out.println(" ");
    				        									System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
    				        									System.out.println("============================");
    				        									System.out.println("1.Purchase");
    				        									System.out.println(" ");
    				        									System.out.println("2.Exit");
    				        									System.out.println("============================");
    				        									System.out.print("Select Your Option :");
    				        									          int purchase =sc.nextInt();
    				        									          switch(purchase)
    				        									          {
    				        									          case 1:
    				        									        	  System.out.println(" ");
    				        									        	  vz.Delivery();
    				        									          break;
    				        									        	  
    				        									          case 2:
    				        									           System.out.println(" ");
    				        									           System.out.println("Thank You For Visiting");
    				        									           System.out.println("Plz Login Again If U Want To Purchase Something");
    				        									           System.out.println(" ");
    				        									           vz.login();
    				        									          break;

    				        									          default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Macha Try Again");
    		        								          

    				        									          }
    				        			                break;//Product Colour 1
    				        							case 2:
    				        								System.out.println(" ");
    				        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
    				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    				        								WaterPurifiers m3 = new WaterPurifiers(560522,"AO Smith ProPlanet P4 RO+SCMT+UV LED Electrical Water Purifier",29600,"Water Purifiers","Purple");
    				        								m3.WaterPurifiersDetails();
    				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    				        								System.out.println(" ");
    				        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
    				        								System.out.println("============================");
    				        								System.out.println("1.Purchase");
    				        								System.out.println(" ");
    				        								System.out.println("2.Exit");
    				        								System.out.println("============================");
    				        								System.out.print("Select Your Option :");
    				        								          int purchase2 =sc.nextInt();
    				        								          switch(purchase2)
    				        								          {
    				        								          case 1:
    				        								        	  System.out.println(" ");
    				        								        	  vz.Delivery();
    				        								          break;
    				        								        	  
    				        								          case 2:
    				        								           System.out.println(" ");
    				        								           System.out.println("Thank You For Visiting");
    				        								           System.out.println("Plz Login Again If U Want To Purchase Something");
    				        								           System.out.println(" ");
    				        								           vz.login();
    				        								          break;

    				        								          default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid  Macha Try Again");

    				        						     
    				        								          }			        								          
    				        							      break;//Product Colour 2

    				        							      default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Colour Macha Try Again");

    				        						   	}//Colour Close
    				        							
    				        				
    				        		    break;//AO Smith ProPlanet P4 RO+SCMT+UV LED Electrical Water Purifier End

    				        			
    				        			case 3://Aquaguard Crystal NXT Water Purifier
    				        				System.out.println(" ");
    				        				System.out.println("⊱---------------------⊰");
    				        				//long productId, String productName, double price, String category, String colour
    				        				//Upcasting 
    				        				Kitchen m5 = new WaterPurifiers(560523,"Aquaguard Crystal NXT Water Purifier",27600,"Water Purifiers","White or Navy Blue");
    				        				m5.KitchenDetails();
    				        				System.out.println("⊱---------------------⊰");
    				        				System.out.println(" ");
    				        				System.out.println("Choose Your Colour");
    				        				System.out.println("===================");
    				        				System.out.println("1.White");
    				        				System.out.println("2.Navy Blue");
    				        				System.out.println("===================");
    				        				System.out.println(" ");
    				        				System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    				        				System.out.print("Which Colour Your Prefer :");
    				        				            //Switch For Colour Choosing 
    				        							int WasColour3 =sc.nextInt();
    				        							System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
    				        							switch(WasColour3)
    				        							{
    				        							case 1:
    				        									System.out.println(" ");
    				        									System.out.println("Your Product Sir/Ma'am :"+vz.Username);
    				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    				        									WaterPurifiers m2 = new WaterPurifiers(560523,"Aquaguard Crystal NXT Water Purifier",27600,"Water Purifiers","White");
    				        									m2.WaterPurifiersDetails();
    				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    				        									System.out.println(" ");
    				        									System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
    				        									System.out.println("============================");
    				        									System.out.println("1.Purchase");
    				        									System.out.println(" ");
    				        									System.out.println("2.Exit");
    				        									System.out.println("============================");
    				        									System.out.print("Select Your Option :");
    				        									          int purchase =sc.nextInt();
    				        									          switch(purchase)
    				        									          {
    				        									          case 1:
    				        									        	  System.out.println(" ");
    				        									        	  vz.Delivery();
    				        									          break;
    				        									        	  
    				        									          case 2:
    				        									           System.out.println(" ");
    				        									           System.out.println("Thank You For Visiting");
    				        									           System.out.println("Plz Login Again If U Want To Purchase Something");
    				        									           System.out.println(" ");
    				        									           vz.login();
    				        									          break;

    				        									          default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid  Macha Try Again");
    				        									          }
    				        			                break;//Product Colour 1
    				        							case 2:
    				        								System.out.println(" ");
    				        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
    				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    				        								WaterPurifiers m3 = new WaterPurifiers(560523,"Aquaguard Crystal NXT Water Purifier",27600,"Water Purifiers","Navy Blue");
    				        								m3.WaterPurifiersDetails();
    				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
    				        								System.out.println(" ");
    				        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
    				        								System.out.println("============================");
    				        								System.out.println("1.Purchase");
    				        								System.out.println(" ");
    				        								System.out.println("2.Exit");
    				        								System.out.println("============================");
    				        								System.out.print("Select Your Option :");
    				        								          int purchase2 =sc.nextInt();
    				        								          switch(purchase2)
    				        								          {
    				        								          case 1:
    				        								        	  System.out.println(" ");
    				        								        	  vz.Delivery();
    				        								          break;
    				        								        	  
    				        								          case 2:
    				        								           System.out.println(" ");
    				        								           System.out.println("Thank You For Visiting");
    				        								           System.out.println("Plz Login Again If U Want To Purchase Something");
    				        								           System.out.println(" ");
    				        								           vz.login();
    				        								          break;


    				        								   default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid  Macha Try Again");

    				        						     
    				        								          }			        								          
    				        							      break;//Product Colour 2

    				        							      default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Colour Macha Try Again");

    				        						   	}//Colour Close
    				        							
    				        				
    				        				break;//Aquaguard Crystal NXT Water Purifier End

    				        		    }
    				        break;//Water Purifiers End

    				        default:
    		        								          System.out.println(" ");
    		        								          System.out.println("Invalid Kitchen Appliances Macha Try Again");



    		      }
    		
            break;
            //------------------------------------Kitchen Appliances End Switch------------------------------------//
	        
	        
          //------------------------------------Laptops Start Switch------------------------------------//
  		case 3:
  		System.out.println("Your Selected Category: Laptops");
  		System.out.println(" ");
  		System.out.println("Laptops Category Sections :");
  		System.out.println("========================");
  		System.out.println("1.Mac Laptops");
  		System.out.println(" ");
  		System.out.println("2.Asus Laptops");
  		System.out.println(" ");
  		System.out.println("3.Dell Laptops");
  		System.out.println("========================");
  		System.out.println(" ");
  		System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  		System.out.print("Select the Appliances :");
  		int Laptops = sc.nextInt();
  		     switch (Laptops) 
  		     {
  		
  		            case 1://Mac Laptops Start
  		            System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  		            System.out.println(" ");
  		            System.out.println("Mac Laptops Section :");
  		            System.out.println("========================");
  			        System.out.println("1.MacBook Air M1");
  			        System.out.println(" ");
  			        System.out.println("2.MacBook Pro M6");
  			        System.out.println(" ");
  			        System.out.println("3.iMac 2000");
  			        System.out.println("========================");
  			        System.out.println(" ");
  			        System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  			        System.out.print("Select Your Mac Laptops :");
  			        int MacLaptops = sc.nextInt();
  			        System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  			        switch (MacLaptops) 
  			        {
  			        			case 1:// Start
  			        			System.out.println(" ");
  			        			System.out.println("⊱---------------------⊰");
  			        			//long productId, String productName, double price, String category, String colour
  			        			//Upcasting 
  			        			Laptops m1 = new MacLaptops(11111,"MacBook Air M1",92000,"Mac Laptops","Metalick Grey & Yellow");
  			        			m1.LaptopsDetails();
  			        			System.out.println("⊱---------------------⊰");
  			        			System.out.println(" ");
  			        			System.out.println("Choose Your Colour");
  			        			System.out.println("===================");
  			        			System.out.println("1.Metalick Grey");
  			        			System.out.println("2.Yellow");
  			        			System.out.println("===================");
  			        			System.out.println(" ");
  			        			System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  			        			System.out.print("Which Colour Your Prefer :");
  			        			            //Switch For Colour Choosing 
  			        						int WasColour =sc.nextInt();
  			        						System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  			        						switch(WasColour)
  			        						{
  			        						case 1:
  			        								System.out.println(" ");
  			        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
  			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  			        								MacLaptops m2 = new MacLaptops(78952,"MacBook Air M1",92000,"Mac Laptops","Metalick Grey");
  			        								m2.MacLaptopsDetails();
  			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  			        								System.out.println(" ");
  			        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
  			        								System.out.println("============================");
  			        								System.out.println("1.Purchase");
  			        								System.out.println(" ");
  			        								System.out.println("2.Exit");
  			        								System.out.println("============================");
  			        								System.out.print("Select Your Option :");
  			        								          int purchase =sc.nextInt();
  			        								          switch(purchase)
  			        								          {
  			        								          case 1:
  			        								        	  System.out.println(" ");
  			        								        	  vz.Delivery();
  			        								          break;
  			        								        	  
  			        								          case 2:
  			        								           System.out.println(" ");
  			        								           System.out.println("Thank You For Visiting");
  			        								           System.out.println("Plz Login Again If U Want To Purchase Something");
  			        								           System.out.println(" ");
  			        								           vz.login();
  			        								          break;

  			        								          default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Macha Try Again");
  			        								          }
  			        		                break;//Product Colour 1
  			        						case 2:
  		        								System.out.println(" ");
  		        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
  		        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  		        								MacLaptops m3 = new MacLaptops(78952,"MacBook Air M1",92000,"Mac Laptops","Yellow");
  		        								m3.MacLaptopsDetails();
  		        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  		        								System.out.println(" ");
  		        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
  		        								System.out.println("============================");
  		        								System.out.println("1.Purchase");
  		        								System.out.println(" ");
  		        								System.out.println("2.Exit");
  		        								System.out.println("============================");
  		        								System.out.print("Select Your Option :");
  		        								          int purchase2 =sc.nextInt();
  		        								          switch(purchase2)
  		        								          {
  		        								          case 1:
  		        								        	  System.out.println(" ");
  		        								        	  vz.Delivery();
  		        								          break;
  		        								        	  
  		        								          case 2:
  		        								           System.out.println(" ");
  		        								           System.out.println("Thank You For Visiting");
  		        								           System.out.println("Plz Login Again If U Want To Purchase Something");
  		        								           System.out.println(" ");
  		        								           vz.login();
  		        								          break;


  		        								          default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Macha Try Again");
  			        					     
  		        								          }			        								          
  			        						      break;//Product Colour 2
  			        						     default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Colour Macha Try Again");
  			        					   	}//Colour Close
  			        						
  			        			
  			        			break;//MacBook Air M1 End
  			        			
  			        			case 2://MacBook Pro M6 Start
  			        				System.out.println(" ");
  			        				System.out.println("⊱---------------------⊰");
  			        				//long productId, String productName, double price, String category, String colour
  			        				//Upcasting 
  			        				Laptops m4 = new MacLaptops(789522,"MacBook Pro M6",100600,"Mac Laptops","Red Or Violet");
  			        				m4.LaptopsDetails();
  			        				System.out.println("⊱---------------------⊰");
  			        				System.out.println(" ");
  			        				System.out.println("Choose Your Colour");
  			        				System.out.println("===================");
  			        				System.out.println("1.Red");
  			        				System.out.println("2.Violet");
  			        				System.out.println("===================");
  			        				System.out.println(" ");
  			        				System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  			        				System.out.print("Which Colour Your Prefer :");
  			        				            //Switch For Colour Choosing 
  			        							int WasColour2 =sc.nextInt();
  			        							System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  			        							switch(WasColour2)
  			        							{
  			        							case 1:
  			        									System.out.println(" ");
  			        									System.out.println("Your Product Sir/Ma'am :"+vz.Username);
  			        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  			        									MacLaptops m2 = new MacLaptops(789522,"MacBook Pro M6",100600,"Mac Laptops","Red");
  			        									m2.MacLaptopsDetails();
  			        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  			        									System.out.println(" ");
  			        									System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
  			        									System.out.println("============================");
  			        									System.out.println("1.Purchase");
  			        									System.out.println(" ");
  			        									System.out.println("2.Exit");
  			        									System.out.println("============================");
  			        									System.out.print("Select Your Option :");
  			        									          int purchase =sc.nextInt();
  			        									          switch(purchase)
  			        									          {
  			        									          case 1:
  			        									        	  System.out.println(" ");
  			        									        	  vz.Delivery();
  			        									          break;
  			        									        	  
  			        									          case 2:
  			        									           System.out.println(" ");
  			        									           System.out.println("Thank You For Visiting");
  			        									           System.out.println("Plz Login Again If U Want To Purchase Something");
  			        									           System.out.println(" ");
  			        									           vz.login();
  			        									          break;
  			        									          default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Macha Try Again");
  			        									          }
  			        			                break;//Product Colour 1
  			        							case 2:
  			        								System.out.println(" ");
  			        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
  			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  			        								MacLaptops m3 = new MacLaptops(789522,"MacBook Pro M6",100800,"Mac Laptops","Violet");
  			        								m3.MacLaptopsDetails();
  			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  			        								System.out.println(" ");
  			        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
  			        								System.out.println("============================");
  			        								System.out.println("1.Purchase");
  			        								System.out.println(" ");
  			        								System.out.println("2.Exit");
  			        								System.out.println("============================");
  			        								System.out.print("Select Your Option :");
  			        								          int purchase2 =sc.nextInt();
  			        								          switch(purchase2)
  			        								          {
  			        								          case 1:
  			        								        	  System.out.println(" ");
  			        								        	  vz.Delivery();
  			        								          break;
  			        								        	  
  			        								          case 2:
  			        								           System.out.println(" ");
  			        								           System.out.println("Thank You For Visiting");
  			        								           System.out.println("Plz Login Again If U Want To Purchase Something");
  			        								           System.out.println(" ");
  			        								           vz.login();
  			        								          break;

  			        								          default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Macha Try Again");
  			        						     
  			        								          }			        								          
  			        							      break;//Product Colour 2

  			        							     default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Colour Macha Try Again");
  			        						   	}//Colour Close
  			        							
  			        				
  			        		    break;////MacBook Pro M6 End

  			        			
  			        			case 3://iMac 2000 Start
  			        				System.out.println(" ");
  			        				System.out.println("⊱---------------------⊰");
  			        				//long productId, String productName, double price, String category, String colour
  			        				//Upcasting 
  			        				Laptops m5 = new MacLaptops(789522,"iMac 2000",156000,"Mac Laptops","Cyan or Black");
  			        				m5.LaptopsDetails();
  			        				System.out.println("⊱---------------------⊰");
  			        				System.out.println(" ");
  			        				System.out.println("Choose Your Colour");
  			        				System.out.println("===================");
  			        				System.out.println("1.Cyan");
  			        				System.out.println("2.Black");
  			        				System.out.println("===================");
  			        				System.out.println(" ");
  			        				System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  			        				System.out.print("Which Colour Your Prefer :");
  			        				            //Switch For Colour Choosing 
  			        							int WasColour3 =sc.nextInt();
  			        							System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  			        							switch(WasColour3)
  			        							{
  			        							case 1:
  			        									System.out.println(" ");
  			        									System.out.println("Your Product Sir/Ma'am :"+vz.Username);
  			        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  			        									MacLaptops m2 = new MacLaptops(789522,"iMac 2000",156000,"Mac Laptops","Cyan");
  			        									m2.MacLaptopsDetails();
  			        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  			        									System.out.println(" ");
  			        									System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
  			        									System.out.println("============================");
  			        									System.out.println("1.Purchase");
  			        									System.out.println(" ");
  			        									System.out.println("2.Exit");
  			        									System.out.println("============================");
  			        									System.out.print("Select Your Option :");
  			        									          int purchase =sc.nextInt();
  			        									          switch(purchase)
  			        									          {
  			        									          case 1:
  			        									        	  System.out.println(" ");
  			        									        	  vz.Delivery();
  			        									          break;
  			        									        	  
  			        									          case 2:
  			        									           System.out.println(" ");
  			        									           System.out.println("Thank You For Visiting");
  			        									           System.out.println("Plz Login Again If U Want To Purchase Something");
  			        									           System.out.println(" ");
  			        									           vz.login();
  			        									          break;

  			        									          default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Macha Try Again");
  			        									          }
  			        			                break;//Product Colour 1
  			        							case 2:
  			        								System.out.println(" ");
  			        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
  			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  			        								MacLaptops m3 = new MacLaptops(789522,"iMac 2000",158000,"Mac Laptops","Black");
  			        								m3.MacLaptopsDetails();
  			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  			        								System.out.println(" ");
  			        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
  			        								System.out.println("============================");
  			        								System.out.println("1.Purchase");
  			        								System.out.println(" ");
  			        								System.out.println("2.Exit");
  			        								System.out.println("============================");
  			        								System.out.print("Select Your Option :");
  			        								          int purchase2 =sc.nextInt();
  			        								          switch(purchase2)
  			        								          {
  			        								          case 1:
  			        								        	  System.out.println(" ");
  			        								        	  vz.Delivery();
  			        								          break;
  			        								        	  
  			        								          case 2:
  			        								           System.out.println(" ");
  			        								           System.out.println("Thank You For Visiting");
  			        								           System.out.println("Plz Login Again If U Want To Purchase Something");
  			        								           System.out.println(" ");
  			        								           vz.login();
  			        								          break;

  			        								          default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Macha Try Again");
  			        						     
  			        								          }			        								          
  			        							      break;//Product Colour 2

  			        							      default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Colour Macha Try Again");
  			        						   	}//Colour Close
  			        							
  			        				
  			        				break;//iMac 2000 End

  			        		    }
  			        break;//Mac Laptops End
  			        
  		            case 2://Asus Laptops Start
  			            System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  			            System.out.println(" ");
  			            System.out.println("Asus Laptops Section :");
  			            System.out.println("========================");
  				        System.out.println("1.Asus VivoBook 15");
  				        System.out.println(" ");
  			            System.out.println("2.Asus VivoBook Pro");
  			            System.out.println(" ");
  			            System.out.println("3.Asus TUF Gaming A15");
  				        System.out.println("========================");
  				        System.out.println(" ");
  				        System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  				        System.out.print("Select Your Asus Laptops :");
  				        int AsusLaptops = sc.nextInt();
  				        System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  				        switch (AsusLaptops) 
  				        {
  				        			case 1://Asus Laptops Start
  				        			System.out.println(" ");
  				        			System.out.println("⊱---------------------⊰");
  				        			//long productId, String productName, double price, String category, String colour
  				        			//Upcasting 
  				        			Laptops m1 = new AsusLaptops(56652l,"Asus VivoBook 15",26600,"Asus Laptops","Green or Maroon");
  				        			m1.LaptopsDetails();
  				        			System.out.println("⊱---------------------⊰");
  				        			System.out.println(" ");
  				        			System.out.println("Choose Your Colour");
  				        			System.out.println("===================");
  				        			System.out.println("1.Green");
  				        			System.out.println("2.Maroon");
  				        			System.out.println("===================");
  				        			System.out.println(" ");
  				        			System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  				        			System.out.print("Which Colour Your Prefer :");
  				        			            //Switch For Colour Choosing 
  				        						int WasColour =sc.nextInt();
  				        						System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  				        						switch(WasColour)
  				        						{
  				        						case 1://Asus VivoBook 15 Start
  				        								System.out.println(" ");
  				        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
  				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  				        								AsusLaptops m2 = new AsusLaptops(56652l,"Asus VivoBook 15",26600,"Asus Laptops","Green");
  				        								m2.AsusLaptopsDetails();
  				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  				        								System.out.println(" ");
  				        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
  				        								System.out.println("============================");
  				        								System.out.println("1.Purchase");
  				        								System.out.println(" ");
  				        								System.out.println("2.Exit");
  				        								System.out.println("============================");
  				        								System.out.print("Select Your Option :");
  				        								          int purchase =sc.nextInt();
  				        								          switch(purchase)
  				        								          {
  				        								          case 1:
  				        								        	  System.out.println(" ");
  				        								        	  vz.Delivery();
  				        								          break;
  				        								        	  
  				        								          case 2:
  				        								           System.out.println(" ");
  				        								           System.out.println("Thank You For Visiting");
  				        								           System.out.println("Plz Login Again If U Want To Purchase Something");
  				        								           System.out.println(" ");
  				        								           vz.login();
  				        								          break;


  				        								           default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Macha Try Again");

  				        								          }
  				        		                break;//Product Colour 1
  				        						case 2:
  			        								System.out.println(" ");
  			        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
  			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  			        								AsusLaptops m3 = new AsusLaptops(56652l,"Asus VivoBook 15",26600,"Asus Laptops","Maroon");
  			        								m3.AsusLaptopsDetails();
  			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  			        								System.out.println(" ");
  			        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
  			        								System.out.println("============================");
  			        								System.out.println("1.Purchase");
  			        								System.out.println(" ");
  			        								System.out.println("2.Exit");
  			        								System.out.println("============================");
  			        								System.out.print("Select Your Option :");
  			        								          int purchase2 =sc.nextInt();
  			        								          switch(purchase2)
  			        								          {
  			        								          case 1:
  			        								        	  System.out.println(" ");
  			        								        	  vz.Delivery();
  			        								          break;
  			        								        	  
  			        								          case 2:
  			        								           System.out.println(" ");
  			        								           System.out.println("Thank You For Visiting");
  			        								           System.out.println("Plz Login Again If U Want To Purchase Something");
  			        								           System.out.println(" ");
  			        								           vz.login();
  			        								          break;

  			        								           default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Macha Try Again");
  				        					     
  			        								          }			        								          
  				        						      break;//Product Colour 2

  				        						       default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Colour Macha Try Again");
  				        					   	}//Colour Close
  				        						
  				        			
  				        			break;//Asus VivoBook 15 End
  				        			
  				        			case 2://Asus VivoBook Pro Start
  				        				System.out.println(" ");
  				        				System.out.println("⊱---------------------⊰");
  				        				//long productId, String productName, double price, String category, String colour
  				        				//Upcasting 
  				        				Laptops m4 = new AsusLaptops(566522,"Asus VivoBook Pro",50600,"Asus Laptops","Black or Pinky");
  				        				m4.LaptopsDetails();
  				        				System.out.println("⊱---------------------⊰");
  				        				System.out.println(" ");
  				        				System.out.println("Choose Your Colour");
  				        				System.out.println("===================");
  				        				System.out.println("1.Black");
  				        				System.out.println("2.Pinky");
  				        				System.out.println("===================");
  				        				System.out.println(" ");
  				        				System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  				        				System.out.print("Which Colour Your Prefer :");
  				        				            //Switch For Colour Choosing 
  				        							int WasColour2 =sc.nextInt();
  				        							System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  				        							switch(WasColour2)
  				        							{
  				        							case 1:
  				        									System.out.println(" ");
  				        									System.out.println("Your Product Sir/Ma'am :"+vz.Username);
  				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  				        									AsusLaptops m2 = new AsusLaptops(566522,"Asus VivoBook Pro",50600,"Asus Laptops","Black");
  				        									m2.AsusLaptopsDetails();
  				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  				        									System.out.println(" ");
  				        									System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
  				        									System.out.println("============================");
  				        									System.out.println("1.Purchase");
  				        									System.out.println(" ");
  				        									System.out.println("2.Exit");
  				        									System.out.println("============================");
  				        									System.out.print("Select Your Option :");
  				        									          int purchase =sc.nextInt();
  				        									          switch(purchase)
  				        									          {
  				        									          case 1:
  				        									        	  System.out.println(" ");
  				        									        	  vz.Delivery();
  				        									          break;
  				        									        	  
  				        									          case 2:
  				        									           System.out.println(" ");
  				        									           System.out.println("Thank You For Visiting");
  				        									           System.out.println("Plz Login Again If U Want To Purchase Something");
  				        									           System.out.println(" ");
  				        									           vz.login();
  				        									          break;


  				        									           default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Macha Try Again");

  				        									          }
  				        			                break;//Product Colour 1
  				        							case 2:
  				        								System.out.println(" ");
  				        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
  				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  				        								AsusLaptops m3 = new AsusLaptops(566522,"Asus VivoBook Pro",50600,"Asus Laptops","Pinky");
  				        								m3.AsusLaptopsDetails();
  				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  				        								System.out.println(" ");
  				        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
  				        								System.out.println("============================");
  				        								System.out.println("1.Purchase");
  				        								System.out.println(" ");
  				        								System.out.println("2.Exit");
  				        								System.out.println("============================");
  				        								System.out.print("Select Your Option :");
  				        								          int purchase2 =sc.nextInt();
  				        								          switch(purchase2)
  				        								          {
  				        								          case 1:
  				        								        	  System.out.println(" ");
  				        								        	  vz.Delivery();
  				        								          break;
  				        								        	  
  				        								          case 2:
  				        								           System.out.println(" ");
  				        								           System.out.println("Thank You For Visiting");
  				        								           System.out.println("Plz Login Again If U Want To Purchase Something");
  				        								           System.out.println(" ");
  				        								           vz.login();
  				        								          break;


  				        								           default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Macha Try Again");
  				        						     
  				        								          }			        								          
  				        							      break;//Product Colour 2

  				        							       default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Colour Macha Try Again");
  				        						   	}//Colour Close
  				        							
  				        				
  				        		    break;//Asus VivoBook Pro End

  				        			
  				        			case 3://Asus TUF Gaming A15 Start
  				        				System.out.println(" ");
  				        				System.out.println("⊱---------------------⊰");
  				        				//long productId, String productName, double price, String category, String colour
  				        				//Upcasting 
  				        				Laptops m5 = new AsusLaptops(566523,"Asus TUF Gaming A15",256000,"Asus Laptops","White or Blue");
  				        				m5.LaptopsDetails();
  				        				System.out.println("⊱---------------------⊰");
  				        				System.out.println(" ");
  				        				System.out.println("Choose Your Colour");
  				        				System.out.println("===================");
  				        				System.out.println("1.White");
  				        				System.out.println("2.Blue");
  				        				System.out.println("===================");
  				        				System.out.println(" ");
  				        				System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  				        				System.out.print("Which Colour Your Prefer :");
  				        				            //Switch For Colour Choosing 
  				        							int WasColour3 =sc.nextInt();
  				        							System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  				        							switch(WasColour3)
  				        							{
  				        							case 1:
  				        									System.out.println(" ");
  				        									System.out.println("Your Product Sir/Ma'am :"+vz.Username);
  				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  				        									AsusLaptops m2 = new AsusLaptops(566523,"Asus TUF Gaming A15",256000,"Asus Laptops","White");
  				        									m2.AsusLaptopsDetails();
  				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  				        									System.out.println(" ");
  				        									System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
  				        									System.out.println("============================");
  				        									System.out.println("1.Purchase");
  				        									System.out.println(" ");
  				        									System.out.println("2.Exit");
  				        									System.out.println("============================");
  				        									System.out.print("Select Your Option :");
  				        									          int purchase =sc.nextInt();
  				        									          switch(purchase)
  				        									          {
  				        									          case 1:
  				        									        	  System.out.println(" ");
  				        									        	  vz.Delivery();
  				        									          break;
  				        									        	  
  				        									          case 2:
  				        									           System.out.println(" ");
  				        									           System.out.println("Thank You For Visiting");
  				        									           System.out.println("");
  				        									           System.out.println(" ");
  				        									           vz.login();
  				        									          break;

  				        									           default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Macha Try Again");
  				        									          }
  				        			                break;//Product Colour 1
  				        							case 2:
  				        								System.out.println(" ");
  				        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
  				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  				        								AsusLaptops m3 = new AsusLaptops(566523,"Asus TUF Gaming A15",256000,"Asus Laptops","Blue");
  				        								m3.AsusLaptopsDetails();
  				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  				        								System.out.println(" ");
  				        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
  				        								System.out.println("============================");
  				        								System.out.println("1.Purchase");
  				        								System.out.println(" ");
  				        								System.out.println("2.Exit");
  				        								System.out.println("============================");
  				        								System.out.print("Select Your Option :");
  				        								          int purchase2 =sc.nextInt();
  				        								          switch(purchase2)
  				        								          {
  				        								          case 1:
  				        								        	  System.out.println(" ");
  				        								        	  vz.Delivery();
  				        								          break;
  				        								        	  
  				        								          case 2:
  				        								           System.out.println(" ");
  				        								           System.out.println("Thank You For Visiting");
  				        								           System.out.println("Plz Login Again If U Want To Purchase Something");
  				        								           System.out.println(" ");
  				        								           vz.login();
  				        								          break;


  				        								           default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Macha Try Again");
  				        						     
  				        								          }			        				          
  				        							      break;//Product Colour 2

  				        							       default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Colour Macha Try Again");
  				        						   	}//Colour Close
  				        							
  				        				
  				        				break;//Asus TUF Gaming A15 End

  				        		    }
  				    break;//Asus Laptops End

  	   
  		            case 3://Dell Laptops Start
  			            System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  			            System.out.println(" ");
  			            System.out.println("Dell Laptops Section :");
  			            System.out.println("========================");
  				        System.out.println("1.Dell Inspiron 3511");
  				        System.out.println(" ");
  			            System.out.println("2.Dell Vostro 3420");
  			            System.out.println(" ");
  			            System.out.println("3.Dell Latitude E6420");
  				        System.out.println("========================");
  				        System.out.println(" ");
  				        System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  				        System.out.print("Select Your Dell Laptops:");
  				        int DellLaptops = sc.nextInt();
  				        System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  				        switch (DellLaptops) 
  				        {
  				        			case 1://Dell Inspiron 3511 Start
  				        			System.out.println(" ");
  				        			System.out.println("⊱---------------------⊰");
  				        			//long productId, String productName, double price, String category, String colour
  				        			//Upcasting 
  				        			Laptops m6 = new DellLaptops(56052l,"Dell Inspiron 3511",25600,"Dell Laptops","Yellow or Orange");
  				        			m6.LaptopsDetails();
  				        			System.out.println("⊱---------------------⊰");
  				        			System.out.println(" ");
  				        			System.out.println("Choose Your Colour");
  				        			System.out.println("===================");
  				        			System.out.println("1.Yellow");
  				        			System.out.println("2.Orange");
  				        			System.out.println("===================");
  				        			System.out.println(" ");
  				        			System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  				        			System.out.print("Which Colour Your Prefer :");
  				        			            //Switch For Colour Choosing 
  				        						int WasColour =sc.nextInt();
  				        						System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  				        						switch(WasColour)
  				        						{
  				        						case 1:
  				        								System.out.println(" ");
  				        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
  				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  				        								DellLaptops m2 = new DellLaptops(56052l,"Dell Inspiron 3511",25600,"Dell Laptops","Yellow");
  				        								m2.DellLaptopsDetails();
  				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  				        								System.out.println(" ");
  				        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
  				        								System.out.println("============================");
  				        								System.out.println("1.Purchase");
  				        								System.out.println(" ");
  				        								System.out.println("2.Exit");
  				        								System.out.println("============================");
  				        								System.out.print("Select Your Option :");
  				        								          int purchase =sc.nextInt();
  				        								          switch(purchase)
  				        								          {
  				        								          case 1:
  				        								        	  System.out.println(" ");
  				        								        	  vz.Delivery();
  				        								          break;
  				        								        	  
  				        								          case 2:
  				        								           System.out.println(" ");
  				        								           System.out.println("Thank You For Visiting");
  				        								           System.out.println("Plz Login Again If U Want To Purchase Something");
  				        								           System.out.println(" ");
  				        								           vz.login();
  				        								          break;
  				        								           default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Macha Try Again");
  				        								          }
  				        		                break;//Product Colour 1
  				        						case 2:
  			        								System.out.println(" ");
  			        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
  			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  			        								DellLaptops m3 = new DellLaptops(56052l,"Dell Inspiron 3511",25600,"Dell Laptops","Orange");
  			        								m3.DellLaptopsDetails();
  			        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  			        								System.out.println(" ");
  			        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
  			        								System.out.println("============================");
  			        								System.out.println("1.Purchase");
  			        								System.out.println(" ");
  			        								System.out.println("2.Exit");
  			        								System.out.println("============================");
  			        								System.out.print("Select Your Option :");
  			        								          int purchase2 =sc.nextInt();
  			        								          switch(purchase2)
  			        								          {
  			        								          case 1:
  			        								        	  System.out.println(" ");
  			        								        	  vz.Delivery();
  			        								          break;
  			        								        	  
  			        								          case 2:
  			        								           System.out.println(" ");
  			        								           System.out.println("Thank You For Visiting");
  			        								           System.out.println("Plz Login Again If U Want To Purchase Something");
  			        								           System.out.println(" ");
  			        								           vz.login();
  			        								          break;
  			        								       default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid  Macha Try Again");
  				        					     
  			        								          }			        								          
  				        						      break;//Product Colour 2

  				        						       default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Colour Macha Try Again");
  				        					   	}//Colour Close
  				        						
  				        			
  				        			break;//Dell Inspiron 3511 End
  				        			
  				        			case 2://Dell Vostro 3420 Start
  				        				System.out.println(" ");
  				        				System.out.println("⊱---------------------⊰");
  				        				//long productId, String productName, double price, String category, String colour
  				        				//Upcasting 
  				        				Laptops m4 = new DellLaptops(560522,"Dell Vostro 3420",29600,"Dell Laptops","Green or Purple");
  				        				m4.LaptopsDetails();
  				        				System.out.println("⊱---------------------⊰");
  				        				System.out.println(" ");
  				        				System.out.println("Choose Your Colour");
  				        				System.out.println("===================");
  				        				System.out.println("1.Green");
  				        				System.out.println("2.Purple");
  				        				System.out.println("===================");
  				        				System.out.println(" ");
  				        				System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  				        				System.out.print("Which Colour Your Prefer :");
  				        				            //Switch For Colour Choosing 
  				        							int WasColour2 =sc.nextInt();
  				        							System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  				        							switch(WasColour2)
  				        							{
  				        							case 1:
  				        									System.out.println(" ");
  				        									System.out.println("Your Product Sir/Ma'am :"+vz.Username);
  				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  				        									DellLaptops m2 = new DellLaptops(560522,"Dell Vostro 3420",29600,"Dell Laptops","Green");
  				        									m2.DellLaptopsDetails();
  				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  				        									System.out.println(" ");
  				        									System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
  				        									System.out.println("============================");
  				        									System.out.println("1.Purchase");
  				        									System.out.println(" ");
  				        									System.out.println("2.Exit");
  				        									System.out.println("============================");
  				        									System.out.print("Select Your Option :");
  				        									          int purchase =sc.nextInt();
  				        									          switch(purchase)
  				        									          {
  				        									          case 1:
  				        									        	  System.out.println(" ");
  				        									        	  vz.Delivery();
  				        									          break;
  				        									        	  
  				        									          case 2:
  				        									           System.out.println(" ");
  				        									           System.out.println("Thank You For Visiting");
  				        									           System.out.println("Plz Login Again If U Want To Purchase Something");
  				        									           System.out.println(" ");
  				        									           vz.login();
  				        									          break;

  				        									          default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Macha Try Again");
  		        								          

  				        									          }
  				        			                break;//Product Colour 1
  				        							case 2:
  				        								System.out.println(" ");
  				        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
  				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  				        								DellLaptops m3 = new DellLaptops(560522,"Dell Vostro 3420",29600,"Dell Laptops","Purple");
  				        								m3.DellLaptopsDetails();
  				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  				        								System.out.println(" ");
  				        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
  				        								System.out.println("============================");
  				        								System.out.println("1.Purchase");
  				        								System.out.println(" ");
  				        								System.out.println("2.Exit");
  				        								System.out.println("============================");
  				        								System.out.print("Select Your Option :");
  				        								          int purchase2 =sc.nextInt();
  				        								          switch(purchase2)
  				        								          {
  				        								          case 1:
  				        								        	  System.out.println(" ");
  				        								        	  vz.Delivery();
  				        								          break;
  				        								        	  
  				        								          case 2:
  				        								           System.out.println(" ");
  				        								           System.out.println("Thank You For Visiting");
  				        								           System.out.println("Plz Login Again If U Want To Purchase Something");
  				        								           System.out.println(" ");
  				        								           vz.login();
  				        								          break;

  				        								          default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid  Macha Try Again");

  				        						     
  				        								          }			        								          
  				        							      break;//Product Colour 2

  				        							      default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Colour Macha Try Again");

  				        						   	}//Colour Close
  				        							
  				        				
  				        		    break;//Dell Vostro 3420 End

  				        			
  				        			case 3://Dell Latitude E6420
  				        				System.out.println(" ");
  				        				System.out.println("⊱---------------------⊰");
  				        				//long productId, String productName, double price, String category, String colour
  				        				//Upcasting 
  				        				Laptops m5 = new DellLaptops(560523,"Dell Latitude E6420",27600,"Dell Laptops","White or Navy Blue");
  				        				m5.LaptopsDetails();
  				        				System.out.println("⊱---------------------⊰");
  				        				System.out.println(" ");
  				        				System.out.println("Choose Your Colour");
  				        				System.out.println("===================");
  				        				System.out.println("1.White");
  				        				System.out.println("2.Navy Blue");
  				        				System.out.println("===================");
  				        				System.out.println(" ");
  				        				System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  				        				System.out.print("Which Colour Your Prefer :");
  				        				            //Switch For Colour Choosing 
  				        							int WasColour3 =sc.nextInt();
  				        							System.out.println("◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤◢◤");
  				        							switch(WasColour3)
  				        							{
  				        							case 1:
  				        									System.out.println(" ");
  				        									System.out.println("Your Product Sir/Ma'am :"+vz.Username);
  				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  				        									DellLaptops m2 = new DellLaptops(560523,"Dell Latitude E6420",27600,"Dell Laptops","White");
  				        									m2.DellLaptopsDetails();
  				        									System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  				        									System.out.println(" ");
  				        									System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
  				        									System.out.println("============================");
  				        									System.out.println("1.Purchase");
  				        									System.out.println(" ");
  				        									System.out.println("2.Exit");
  				        									System.out.println("============================");
  				        									System.out.print("Select Your Option :");
  				        									          int purchase =sc.nextInt();
  				        									          switch(purchase)
  				        									          {
  				        									          case 1:
  				        									        	  System.out.println(" ");
  				        									        	  vz.Delivery();
  				        									          break;
  				        									        	  
  				        									          case 2:
  				        									           System.out.println(" ");
  				        									           System.out.println("Thank You For Visiting");
  				        									           System.out.println("Plz Login Again If U Want To Purchase Something");
  				        									           System.out.println(" ");
  				        									           vz.login();
  				        									          break;

  				        									          default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid  Macha Try Again");
  				        									          }
  				        			                break;//Product Colour 1
  				        							case 2:
  				        								System.out.println(" ");
  				        								System.out.println("Your Product Sir/Ma'am :"+vz.Username);
  				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  				        								DellLaptops m3 = new DellLaptops(560523,"Dell Latitude E6420",27600,"Dell Laptops","Navy Blue");
  				        								m3.DellLaptopsDetails();
  				        								System.out.println("⊱ ───ஓ๑♡๑ஓ ─── ⊰");
  				        								System.out.println(" ");
  				        								System.out.println("Do You Like To Buy Sir/Ma'am :"+vz.Username);
  				        								System.out.println("============================");
  				        								System.out.println("1.Purchase");
  				        								System.out.println(" ");
  				        								System.out.println("2.Exit");
  				        								System.out.println("============================");
  				        								System.out.print("Select Your Option :");
  				        								          int purchase2 =sc.nextInt();
  				        								          switch(purchase2)
  				        								          {
  				        								          case 1:
  				        								        	  System.out.println(" ");
  				        								        	  vz.Delivery();
  				        								          break;
  				        								        	  
  				        								          case 2:
  				        								           System.out.println(" ");
  				        								           System.out.println("Thank You For Visiting");
  				        								           System.out.println("Plz Login Again If U Want To Purchase Something");
  				        								           System.out.println(" ");
  				        								           vz.login();
  				        								          break;


  				        								   default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid  Macha Try Again");

  				        						     
  				        								          }			        								          
  				        							      break;//Product Colour 2

  				        							      default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Colour Macha Try Again");

  				        						   	}//Colour Close
  				        							
  				        				
  				        				break;//Dell Latitude E6420 End

  				        		    }
  				        break;//Dell Laptops End

  				        default:
  		        								          System.out.println(" ");
  		        								          System.out.println("Invalid Laptops Macha Try Again");



  		      }
  		
          break;
          //------------------------------------Laptops End Switch------------------------------------//
			
		
			
		
			
		
			
			default:System.out.println("INVALID CATEGORY !!! MACHA TRY AGAIN");
	 
			
	 }
 }
}


